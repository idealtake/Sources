﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("IDEALTAKE")> 
<Assembly: AssemblyDescription("Moteur de recherche de documents utilisant le SGBD MysQL")> 
<Assembly: AssemblyCompany("VIEIL THIERRY")> 
<Assembly: AssemblyProduct("IDEALTAKE")> 
<Assembly: AssemblyCopyright("Copyright © VIEIL Thierry 2007-2013")> 
<Assembly: AssemblyTrademark("IDEALTAKE")> 

<Assembly: ComVisible(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("91eaf73a-df0d-49ae-9033-f5480b0e3fb5")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.4.494.3719")> 
<Assembly: AssemblyFileVersion("1.4.494.3719")> 

<Assembly: NeutralResourcesLanguageAttribute("fr")> 