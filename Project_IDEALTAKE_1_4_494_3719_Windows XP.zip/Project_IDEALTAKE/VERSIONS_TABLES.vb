﻿
Namespace CLASS_IDEALTAKE.CLASS_IDEALTAKE.Objects
    Class VERSIONS_TABLES

    End Class
End Namespace
