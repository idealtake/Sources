<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Demarrage

    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Demarrage))
        Me.TimerEtatRS = New System.Windows.Forms.Timer(Me.components)
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.WebBrowser_Gestion_Base = New System.Windows.Forms.WebBrowser()
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.Gestion_Base_GroupBox = New System.Windows.Forms.GroupBox()
        Me.Label_Sauvegarde_Base = New System.Windows.Forms.Label()
        Me.Restauration_Base = New System.Windows.Forms.Button()
        Me.Sauvegarde_Base = New System.Windows.Forms.Button()
        Me.Bouton_parametre = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.RS_GroupBox = New System.Windows.Forms.GroupBox()
        Me.RS_MOTS_CLEFS = New System.Windows.Forms.TextBox()
        Me.S�parateur3_Image = New System.Windows.Forms.PictureBox()
        Me.S�parateur4_Image = New System.Windows.Forms.PictureBox()
        Me.S�parateur2_Image = New System.Windows.Forms.PictureBox()
        Me.S�parateur1_Image = New System.Windows.Forms.PictureBox()
        Me.RS_R�f�rences_ComboBox = New System.Windows.Forms.ComboBox()
        Me.RS_Reference_ContextMenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.RS_CONSTRUCTEURS_ComboBox = New System.Windows.Forms.ComboBox()
        Me.RS_Exclure_ListBox = New System.Windows.Forms.ListBox()
        Me.RS_Inclure_ListBox = New System.Windows.Forms.ListBox()
        Me.RS_Exclure_Moin_Button = New System.Windows.Forms.Button()
        Me.RS_Exclure_Plus_Button = New System.Windows.Forms.Button()
        Me.RS_Inclure_Moin_Button = New System.Windows.Forms.Button()
        Me.RS_Inclure_Plus_Button = New System.Windows.Forms.Button()
        Me.RS_Exclure_Label = New System.Windows.Forms.Label()
        Me.RS_Mot_Clef_Label = New System.Windows.Forms.Label()
        Me.RS_Inclure_Label = New System.Windows.Forms.Label()
        Me.RS_CheckBox = New System.Windows.Forms.CheckBox()
        Me.RS_NOM_ENREGISTREMENT = New System.Windows.Forms.TextBox()
        Me.RS_Nom_Enregistrement_Label = New System.Windows.Forms.Label()
        Me.Button_Recherche_Simplifi�e = New System.Windows.Forms.Button()
        Me.Button_Annuler_Recherche_Simplifi�e = New System.Windows.Forms.Button()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.TableLayoutPanel_Image_RS = New System.Windows.Forms.TableLayoutPanel()
        Me.PictureBox_LOGO_RS = New System.Windows.Forms.PictureBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem12 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.RA_GroupBox = New System.Windows.Forms.GroupBox()
        Me.UserControl_RA_references = New IDEALTAKE.UserControl1()
        Me.Documents_Disponibles = New System.Windows.Forms.ListBox()
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem39 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Documents_Recherch�es = New System.Windows.Forms.ListBox()
        Me.Effacer_la_liste_de_documents = New System.Windows.Forms.Button()
        Me.Ajouter_un_document = New System.Windows.Forms.Button()
        Me.Label_PARAM_G_I = New System.Windows.Forms.Label()
        Me.Label_PARAM_F_H = New System.Windows.Forms.Label()
        Me.ComboBox_PARAM_I = New System.Windows.Forms.ComboBox()
        Me.Label_PARAM_I = New System.Windows.Forms.Label()
        Me.ComboBox_PARAM_G = New System.Windows.Forms.ComboBox()
        Me.Label_PARAM_G = New System.Windows.Forms.Label()
        Me.RA_CheckBox_1 = New System.Windows.Forms.CheckBox()
        Me.ComboBox_PARAM_H = New System.Windows.Forms.ComboBox()
        Me.ComboBox_PARAM_F = New System.Windows.Forms.ComboBox()
        Me.RA_CheckBox_2 = New System.Windows.Forms.CheckBox()
        Me.Button_Annuler_Recherche_Avanc�e = New System.Windows.Forms.Button()
        Me.Label_PARAM_F = New System.Windows.Forms.Label()
        Me.ComboBox_TABLE_E = New System.Windows.Forms.ComboBox()
        Me.ComboBox_TABLE_C = New System.Windows.Forms.ComboBox()
        Me.Label_TABLE_D = New System.Windows.Forms.Label()
        Me.Label_TABLE_C = New System.Windows.Forms.Label()
        Me.Button_Recherche_Avanc�e = New System.Windows.Forms.Button()
        Me.Label_TABLE_E = New System.Windows.Forms.Label()
        Me.ComboBox_TABLE_D = New System.Windows.Forms.ComboBox()
        Me.Label_TABLE_B = New System.Windows.Forms.Label()
        Me.Label_PARAM_H = New System.Windows.Forms.Label()
        Me.ComboBox_TABLE_B = New System.Windows.Forms.ComboBox()
        Me.Label_RA_REF = New System.Windows.Forms.Label()
        Me.Label_TABLE_A = New System.Windows.Forms.Label()
        Me.ComboBox_TABLE_A = New System.Windows.Forms.ComboBox()
        Me.WebBrowser2 = New System.Windows.Forms.WebBrowser()
        Me.TableLayoutPanel_Image_RA = New System.Windows.Forms.TableLayoutPanel()
        Me.PictureBox_LOGO_RA = New System.Windows.Forms.PictureBox()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.Recherche_guid�e_TreeView = New System.Windows.Forms.TreeView()
        Me.WebBrowser3 = New System.Windows.Forms.WebBrowser()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.PictureBox_LOGO_Statistiques = New System.Windows.Forms.PictureBox()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.GROUP_STATISTIQUE = New System.Windows.Forms.GroupBox()
        Me.PictureBox_Statistique_commun_verticale_droite = New System.Windows.Forms.PictureBox()
        Me.PictureBox_Statistique_commun_horizontale = New System.Windows.Forms.PictureBox()
        Me.PictureBox_Statistique_commun_verticale_gauche = New System.Windows.Forms.PictureBox()
        Me.Bordure_Statistique_Milieu_Verticale = New System.Windows.Forms.PictureBox()
        Me.Bordure_Statistique_Droite = New System.Windows.Forms.PictureBox()
        Me.Bordure_Statistique_Gauche = New System.Windows.Forms.PictureBox()
        Me.Bordure_Statistique_Basse = New System.Windows.Forms.PictureBox()
        Me.Bordure_Statistique_Haute = New System.Windows.Forms.PictureBox()
        Me.Button_Statistique_Enregistrer_Rapport = New System.Windows.Forms.Button()
        Me.TextBox_Statistique_nom_du_rapport_�_sauver = New System.Windows.Forms.TextBox()
        Me.Label_Statistique_Nom_du_rapport_a_sauver = New System.Windows.Forms.Label()
        Me.Button_Statistique_S�lection_Imprimante = New System.Windows.Forms.Button()
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard� = New System.Windows.Forms.Button()
        Me.Button_Statistique_Effacer_la_recherche = New System.Windows.Forms.Button()
        Me.Button_Statistique_Suppression_Rapport_Sauvegard� = New System.Windows.Forms.Button()
        Me.Label_Statistique_Rapports_Sauvegard�s = New System.Windows.Forms.Label()
        Me.ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s = New System.Windows.Forms.ComboBox()
        Me.Button_Statistique_Ouvrir_Rapport_Sauvegard� = New System.Windows.Forms.Button()
        Me.Label_Statistique_Code_Document = New System.Windows.Forms.Label()
        Me.TextBox_Statistique_CODE_SCHEMA = New System.Windows.Forms.TextBox()
        Me.ComboBox_Statistique_Type_recherche = New System.Windows.Forms.ComboBox()
        Me.Label_Statistique_Selection = New System.Windows.Forms.Label()
        Me.Button_Statistique_Visualiser_la_recherche = New System.Windows.Forms.Button()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.PICTURE_STAT = New System.Windows.Forms.PictureBox()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel7 = New System.Windows.Forms.TableLayoutPanel()
        Me.Personnaliser_Conteneur_Parent_GroupBox = New System.Windows.Forms.GroupBox()
        Me.Group_Synthese_vocale = New System.Windows.Forms.GroupBox()
        Me.CheckBox_Activation_synthese_vocale = New System.Windows.Forms.CheckBox()
        Me.Parametres_synthese_vocale = New System.Windows.Forms.Button()
        Me.Parle = New System.Windows.Forms.Button()
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox = New System.Windows.Forms.GroupBox()
        Me.Personnaliser_Utilisateurs_Action_GroupBox = New System.Windows.Forms.GroupBox()
        Me.RadioButton28 = New System.Windows.Forms.RadioButton()
        Me.RadioButton30 = New System.Windows.Forms.RadioButton()
        Me.RadioButton29 = New System.Windows.Forms.RadioButton()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Bonjour_Utilisateur = New System.Windows.Forms.Label()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Personnaliser_Conteneur_Non_utilis�_GroupBox = New System.Windows.Forms.GroupBox()
        Me.Personnaliser_Couleurs_Recherches_GroupBox = New System.Windows.Forms.GroupBox()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Personnaliser_Couleurs_Texte_GroupBox = New System.Windows.Forms.GroupBox()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Personnaliser_Images__GroupBox = New System.Windows.Forms.GroupBox()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Aide_GroupBox = New System.Windows.Forms.GroupBox()
        Me.LicenceGPL = New System.Windows.Forms.Button()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Diagnostique_connexion = New System.Windows.Forms.Button()
        Me.Utilisateur = New System.Windows.Forms.Label()
        Me.Label_nom_utilisateur = New System.Windows.Forms.Label()
        Me.Nom_de_la_base = New System.Windows.Forms.Label()
        Me.Label_Nom_de_la_base = New System.Windows.Forms.Label()
        Me.Adresse_Serveur = New System.Windows.Forms.Label()
        Me.Label_Adresse_Serveur = New System.Windows.Forms.Label()
        Me.Label_Nom_Connexion = New System.Windows.Forms.Label()
        Me.Nom_Connexion = New System.Windows.Forms.Label()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.SERVEUR_DISPONIBLE = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Texte_Aide = New System.Windows.Forms.TextBox()
        Me.ImageList_TabControl1 = New System.Windows.Forms.ImageList(Me.components)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem13 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackColor_ToolStripComboBox = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripMenuItem14 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackGroungImage_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem15 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackGroungImageLayout_ToolStripComboBox = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripMenuItem16 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Cursor_ToolStripComboBox = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripMenuItem17 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Font_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem18 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForeColor_ToolStripComboBox = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripMenuItem19 = New System.Windows.Forms.ToolStripMenuItem()
        Me.hauteur_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem20 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Items_Allemand_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem21 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Items_Anglais_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem22 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Items_Espagnole_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem23 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Items_Francais_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem24 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Items_Italien_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem25 = New System.Windows.Forms.ToolStripMenuItem()
        Me.largeur_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem26 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Position_X_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem27 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Position_Y_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem28 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TabIndex_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem29 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Text_Allemand_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem30 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Text_Anglais_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem31 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Text_Espagnole_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem32 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Text_Francais_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem33 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Text_Italien_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem34 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip_Allemand_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem35 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip_Anglais_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem36 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip_Espagnole_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem37 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip_Francais_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripMenuItem38 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip_Italien_ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
        Me.PageSetupDialog1 = New System.Windows.Forms.PageSetupDialog()
        Me.Timer1EtatServeur = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2EtatServeur = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Restauration_Base_OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.ZoomToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ZoomPlusToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ZoomMoinToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetZoomToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.T�che_de_fond = New System.ComponentModel.BackgroundWorker()
        Me.Timer_Verification_excution_SAPI5 = New System.Windows.Forms.Timer(Me.components)
        Me.T�che_de_fond_SAPI = New System.ComponentModel.BackgroundWorker()
        Me.T�che_de_fond_RS_MOTS_CLEFS = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker_RS = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker_RA = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker_RG = New System.ComponentModel.BackgroundWorker()
        Me.Timer3AutocompleteRsMotsClefs = New System.Windows.Forms.Timer(Me.components)
        Me.TimerEtatRA = New System.Windows.Forms.Timer(Me.components)
        Me.TimerEtatRG = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorker_Diagnostic = New System.ComponentModel.BackgroundWorker()
        Me.TimerEtatDiagnostic = New System.Windows.Forms.Timer(Me.components)
        Me.TimerEtatDetailsEnregistrementW1 = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerDetailsEnregistrementW1 = New System.ComponentModel.BackgroundWorker()
        Me.TimerEtatDetailsEnregistrementW2 = New System.Windows.Forms.Timer(Me.components)
        Me.TimerEtatDetailsEnregistrementW3 = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerDetailsEnregistrementW2 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorkerDetailsEnregistrementW3 = New System.ComponentModel.BackgroundWorker()
        Me.TimerEtatRechercheGestionBase = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerRechercheGestionBase = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorkerAjoutCompteGestionBase = New System.ComponentModel.BackgroundWorker()
        Me.TimerEtatAjoutCompteGestionBase = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerAuthentificationtCompteGestionBase = New System.ComponentModel.BackgroundWorker()
        Me.TimerEtatAuthentificationtCompteGestionBase = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerR�cup�rationCompteGestionBase = New System.ComponentModel.BackgroundWorker()
        Me.TimerEtatR�cup�rationCompteGestionBase = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerSupprimerCompteGestionBase = New System.ComponentModel.BackgroundWorker()
        Me.TimerEtatSupprimerCompteGestionBase = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerSupprimeEnregistrement = New System.ComponentModel.BackgroundWorker()
        Me.TimerSupprimeEnregistrement = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerAjoutEnregistrement = New System.ComponentModel.BackgroundWorker()
        Me.TimerEtatAjoutEnregistrement = New System.Windows.Forms.Timer(Me.components)
        Me.TimerEtatAjoutTreeviewPosition = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerAjoutTreeviewPosition = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorkerAjoutLiensR�f�rences = New System.ComponentModel.BackgroundWorker()
        Me.TimerEtatAjoutLiensR�f�rences = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerSupprimeLiensR�f�rences = New System.ComponentModel.BackgroundWorker()
        Me.TimerEtatSupprimeLiensR�f�rences = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerTransfert = New System.ComponentModel.BackgroundWorker()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.BackgroundWorkerChargementEnregistrement = New System.ComponentModel.BackgroundWorker()
        Me.TimerChargementEnregistrement = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerMise�JourEnregistrement = New System.ComponentModel.BackgroundWorker()
        Me.TimerMise�JourEnregistrement = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorkerMiniVLCPlayer = New System.ComponentModel.BackgroundWorker()
        Me.TabControl1.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.Gestion_Base_GroupBox.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.RS_GroupBox.SuspendLayout()
        CType(Me.S�parateur3_Image, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.S�parateur4_Image, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.S�parateur2_Image, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.S�parateur1_Image, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel_Image_RS.SuspendLayout()
        CType(Me.PictureBox_LOGO_RS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        Me.MenuStrip2.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.RA_GroupBox.SuspendLayout()
        Me.ContextMenuStrip2.SuspendLayout()
        Me.TableLayoutPanel_Image_RA.SuspendLayout()
        CType(Me.PictureBox_LOGO_RA, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        CType(Me.PictureBox_LOGO_Statistiques, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.GROUP_STATISTIQUE.SuspendLayout()
        CType(Me.PictureBox_Statistique_commun_verticale_droite, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_Statistique_commun_horizontale, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_Statistique_commun_verticale_gauche, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bordure_Statistique_Milieu_Verticale, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bordure_Statistique_Droite, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bordure_Statistique_Gauche, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bordure_Statistique_Basse, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bordure_Statistique_Haute, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel5.SuspendLayout()
        CType(Me.PICTURE_STAT, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        Me.TableLayoutPanel7.SuspendLayout()
        Me.Personnaliser_Conteneur_Parent_GroupBox.SuspendLayout()
        Me.Group_Synthese_vocale.SuspendLayout()
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.SuspendLayout()
        Me.Personnaliser_Utilisateurs_Action_GroupBox.SuspendLayout()
        Me.Personnaliser_Couleurs_Recherches_GroupBox.SuspendLayout()
        Me.Personnaliser_Couleurs_Texte_GroupBox.SuspendLayout()
        Me.Personnaliser_Images__GroupBox.SuspendLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Aide_GroupBox.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TimerEtatRS
        '
        Me.TimerEtatRS.Interval = 1000
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.ImageList = Me.ImageList_TabControl1
        Me.TabControl1.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me.TabControl1.ItemSize = New System.Drawing.Size(10, 34)
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Padding = New System.Drawing.Point(4, 2)
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(974, 572)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.BackgroundImage = CType(resources.GetObject("TabPage4.BackgroundImage"), System.Drawing.Image)
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage4.Controls.Add(Me.WebBrowser_Gestion_Base)
        Me.TabPage4.Controls.Add(Me.TableLayoutPanel6)
        Me.TabPage4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TabPage4.ImageIndex = 0
        Me.TabPage4.Location = New System.Drawing.Point(4, 38)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(966, 530)
        Me.TabPage4.TabIndex = 4
        Me.TabPage4.Text = "Gestion Base"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'WebBrowser_Gestion_Base
        '
        Me.WebBrowser_Gestion_Base.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser_Gestion_Base.Location = New System.Drawing.Point(0, 0)
        Me.WebBrowser_Gestion_Base.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser_Gestion_Base.Name = "WebBrowser_Gestion_Base"
        Me.WebBrowser_Gestion_Base.ScriptErrorsSuppressed = True
        Me.WebBrowser_Gestion_Base.Size = New System.Drawing.Size(964, 428)
        Me.WebBrowser_Gestion_Base.TabIndex = 5
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.ColumnCount = 1
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel6.Controls.Add(Me.Gestion_Base_GroupBox, 0, 0)
        Me.TableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(0, 428)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 1
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(964, 100)
        Me.TableLayoutPanel6.TabIndex = 4
        '
        'Gestion_Base_GroupBox
        '
        Me.Gestion_Base_GroupBox.BackColor = System.Drawing.Color.DarkTurquoise
        Me.Gestion_Base_GroupBox.Controls.Add(Me.Label_Sauvegarde_Base)
        Me.Gestion_Base_GroupBox.Controls.Add(Me.Restauration_Base)
        Me.Gestion_Base_GroupBox.Controls.Add(Me.Sauvegarde_Base)
        Me.Gestion_Base_GroupBox.Controls.Add(Me.Bouton_parametre)
        Me.Gestion_Base_GroupBox.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Gestion_Base_GroupBox.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Gestion_Base_GroupBox.Location = New System.Drawing.Point(3, 14)
        Me.Gestion_Base_GroupBox.Name = "Gestion_Base_GroupBox"
        Me.Gestion_Base_GroupBox.Size = New System.Drawing.Size(958, 83)
        Me.Gestion_Base_GroupBox.TabIndex = 3
        Me.Gestion_Base_GroupBox.TabStop = False
        '
        'Label_Sauvegarde_Base
        '
        Me.Label_Sauvegarde_Base.AutoSize = True
        Me.Label_Sauvegarde_Base.BackColor = System.Drawing.Color.Transparent
        Me.Label_Sauvegarde_Base.Location = New System.Drawing.Point(126, 13)
        Me.Label_Sauvegarde_Base.Name = "Label_Sauvegarde_Base"
        Me.Label_Sauvegarde_Base.Size = New System.Drawing.Size(22, 13)
        Me.Label_Sauvegarde_Base.TabIndex = 18
        Me.Label_Sauvegarde_Base.Text = "- - -"
        '
        'Restauration_Base
        '
        Me.Restauration_Base.AutoSize = True
        Me.Restauration_Base.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Restauration_Base.BackColor = System.Drawing.Color.Transparent
        Me.Restauration_Base.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue
        Me.Restauration_Base.Location = New System.Drawing.Point(252, 32)
        Me.Restauration_Base.Name = "Restauration_Base"
        Me.Restauration_Base.Size = New System.Drawing.Size(118, 36)
        Me.Restauration_Base.TabIndex = 17
        Me.Restauration_Base.UseVisualStyleBackColor = False
        '
        'Sauvegarde_Base
        '
        Me.Sauvegarde_Base.AutoSize = True
        Me.Sauvegarde_Base.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Sauvegarde_Base.BackColor = System.Drawing.Color.Transparent
        Me.Sauvegarde_Base.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue
        Me.Sauvegarde_Base.Location = New System.Drawing.Point(129, 32)
        Me.Sauvegarde_Base.Name = "Sauvegarde_Base"
        Me.Sauvegarde_Base.Size = New System.Drawing.Size(118, 36)
        Me.Sauvegarde_Base.TabIndex = 16
        Me.Sauvegarde_Base.UseVisualStyleBackColor = False
        '
        'Bouton_parametre
        '
        Me.Bouton_parametre.AutoSize = True
        Me.Bouton_parametre.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Bouton_parametre.BackColor = System.Drawing.Color.Transparent
        Me.Bouton_parametre.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Bouton_parametre.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue
        Me.Bouton_parametre.Location = New System.Drawing.Point(6, 32)
        Me.Bouton_parametre.Name = "Bouton_parametre"
        Me.Bouton_parametre.Size = New System.Drawing.Size(118, 36)
        Me.Bouton_parametre.TabIndex = 15
        Me.Bouton_parametre.UseVisualStyleBackColor = False
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Transparent
        Me.TabPage2.BackgroundImage = Global.IDEALTAKE.My.Resources.Resources.Pict0017j
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage2.Controls.Add(Me.MenuStrip1)
        Me.TabPage2.Controls.Add(Me.TableLayoutPanel2)
        Me.TabPage2.Controls.Add(Me.WebBrowser1)
        Me.TabPage2.Controls.Add(Me.TableLayoutPanel_Image_RS)
        Me.TabPage2.ImageIndex = 1
        Me.TabPage2.Location = New System.Drawing.Point(4, 38)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(966, 530)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Recherche Simplifi�e"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem5})
        Me.MenuStrip1.Location = New System.Drawing.Point(17, 13)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.Size = New System.Drawing.Size(90, 24)
        Me.MenuStrip1.TabIndex = 13
        Me.MenuStrip1.Text = "MenuStrip1"
        Me.MenuStrip1.Visible = False
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem6, Me.ToolStripMenuItem7, Me.ToolStripMenuItem8})
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(82, 20)
        Me.ToolStripMenuItem5.Text = "Zoom 100%"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(183, 22)
        Me.ToolStripMenuItem6.Text = "Zoom +"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(183, 22)
        Me.ToolStripMenuItem7.Text = "Zoom -"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(183, 22)
        Me.ToolStripMenuItem8.Text = "Reset Zoom"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 710.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.RS_GroupBox, 1, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 366)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(958, 159)
        Me.TableLayoutPanel2.TabIndex = 14
        '
        'RS_GroupBox
        '
        Me.RS_GroupBox.BackColor = System.Drawing.Color.LightCyan
        Me.RS_GroupBox.Controls.Add(Me.RS_MOTS_CLEFS)
        Me.RS_GroupBox.Controls.Add(Me.S�parateur3_Image)
        Me.RS_GroupBox.Controls.Add(Me.S�parateur4_Image)
        Me.RS_GroupBox.Controls.Add(Me.S�parateur2_Image)
        Me.RS_GroupBox.Controls.Add(Me.S�parateur1_Image)
        Me.RS_GroupBox.Controls.Add(Me.RS_R�f�rences_ComboBox)
        Me.RS_GroupBox.Controls.Add(Me.RS_CONSTRUCTEURS_ComboBox)
        Me.RS_GroupBox.Controls.Add(Me.RS_Exclure_ListBox)
        Me.RS_GroupBox.Controls.Add(Me.RS_Inclure_ListBox)
        Me.RS_GroupBox.Controls.Add(Me.RS_Exclure_Moin_Button)
        Me.RS_GroupBox.Controls.Add(Me.RS_Exclure_Plus_Button)
        Me.RS_GroupBox.Controls.Add(Me.RS_Inclure_Moin_Button)
        Me.RS_GroupBox.Controls.Add(Me.RS_Inclure_Plus_Button)
        Me.RS_GroupBox.Controls.Add(Me.RS_Exclure_Label)
        Me.RS_GroupBox.Controls.Add(Me.RS_Mot_Clef_Label)
        Me.RS_GroupBox.Controls.Add(Me.RS_Inclure_Label)
        Me.RS_GroupBox.Controls.Add(Me.RS_CheckBox)
        Me.RS_GroupBox.Controls.Add(Me.RS_NOM_ENREGISTREMENT)
        Me.RS_GroupBox.Controls.Add(Me.RS_Nom_Enregistrement_Label)
        Me.RS_GroupBox.Controls.Add(Me.Button_Recherche_Simplifi�e)
        Me.RS_GroupBox.Controls.Add(Me.Button_Annuler_Recherche_Simplifi�e)
        Me.RS_GroupBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RS_GroupBox.Location = New System.Drawing.Point(127, 3)
        Me.RS_GroupBox.Name = "RS_GroupBox"
        Me.RS_GroupBox.Size = New System.Drawing.Size(704, 153)
        Me.RS_GroupBox.TabIndex = 1
        Me.RS_GroupBox.TabStop = False
        '
        'RS_MOTS_CLEFS
        '
        Me.RS_MOTS_CLEFS.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.RS_MOTS_CLEFS.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.RS_MOTS_CLEFS.Location = New System.Drawing.Point(6, 98)
        Me.RS_MOTS_CLEFS.Name = "RS_MOTS_CLEFS"
        Me.RS_MOTS_CLEFS.Size = New System.Drawing.Size(125, 20)
        Me.RS_MOTS_CLEFS.TabIndex = 23
        '
        'S�parateur3_Image
        '
        Me.S�parateur3_Image.BackColor = System.Drawing.Color.LightSteelBlue
        Me.S�parateur3_Image.Location = New System.Drawing.Point(136, 62)
        Me.S�parateur3_Image.Margin = New System.Windows.Forms.Padding(0)
        Me.S�parateur3_Image.Name = "S�parateur3_Image"
        Me.S�parateur3_Image.Size = New System.Drawing.Size(5, 30)
        Me.S�parateur3_Image.TabIndex = 22
        Me.S�parateur3_Image.TabStop = False
        '
        'S�parateur4_Image
        '
        Me.S�parateur4_Image.BackColor = System.Drawing.Color.LightSteelBlue
        Me.S�parateur4_Image.Location = New System.Drawing.Point(136, 99)
        Me.S�parateur4_Image.Margin = New System.Windows.Forms.Padding(0)
        Me.S�parateur4_Image.Name = "S�parateur4_Image"
        Me.S�parateur4_Image.Size = New System.Drawing.Size(5, 40)
        Me.S�parateur4_Image.TabIndex = 21
        Me.S�parateur4_Image.TabStop = False
        '
        'S�parateur2_Image
        '
        Me.S�parateur2_Image.BackColor = System.Drawing.Color.LightSteelBlue
        Me.S�parateur2_Image.Location = New System.Drawing.Point(136, 31)
        Me.S�parateur2_Image.Margin = New System.Windows.Forms.Padding(0)
        Me.S�parateur2_Image.Name = "S�parateur2_Image"
        Me.S�parateur2_Image.Size = New System.Drawing.Size(5, 20)
        Me.S�parateur2_Image.TabIndex = 20
        Me.S�parateur2_Image.TabStop = False
        '
        'S�parateur1_Image
        '
        Me.S�parateur1_Image.BackColor = System.Drawing.Color.LightSteelBlue
        Me.S�parateur1_Image.Location = New System.Drawing.Point(136, 16)
        Me.S�parateur1_Image.Margin = New System.Windows.Forms.Padding(0)
        Me.S�parateur1_Image.Name = "S�parateur1_Image"
        Me.S�parateur1_Image.Size = New System.Drawing.Size(5, 10)
        Me.S�parateur1_Image.TabIndex = 19
        Me.S�parateur1_Image.TabStop = False
        '
        'RS_R�f�rences_ComboBox
        '
        Me.RS_R�f�rences_ComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.RS_R�f�rences_ComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.RS_R�f�rences_ComboBox.ContextMenuStrip = Me.RS_Reference_ContextMenuStrip
        Me.RS_R�f�rences_ComboBox.FormattingEnabled = True
        Me.RS_R�f�rences_ComboBox.Location = New System.Drawing.Point(363, 19)
        Me.RS_R�f�rences_ComboBox.Name = "RS_R�f�rences_ComboBox"
        Me.RS_R�f�rences_ComboBox.Size = New System.Drawing.Size(207, 21)
        Me.RS_R�f�rences_ComboBox.TabIndex = 12
        '
        'RS_Reference_ContextMenuStrip
        '
        Me.RS_Reference_ContextMenuStrip.Name = "RS_Reference_ContextMenuStrip"
        Me.RS_Reference_ContextMenuStrip.Size = New System.Drawing.Size(61, 4)
        '
        'RS_CONSTRUCTEURS_ComboBox
        '
        Me.RS_CONSTRUCTEURS_ComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.RS_CONSTRUCTEURS_ComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.RS_CONSTRUCTEURS_ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.RS_CONSTRUCTEURS_ComboBox.FormattingEnabled = True
        Me.RS_CONSTRUCTEURS_ComboBox.Location = New System.Drawing.Point(153, 19)
        Me.RS_CONSTRUCTEURS_ComboBox.Name = "RS_CONSTRUCTEURS_ComboBox"
        Me.RS_CONSTRUCTEURS_ComboBox.Size = New System.Drawing.Size(207, 21)
        Me.RS_CONSTRUCTEURS_ComboBox.TabIndex = 7
        '
        'RS_Exclure_ListBox
        '
        Me.RS_Exclure_ListBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RS_Exclure_ListBox.ForeColor = System.Drawing.Color.OrangeRed
        Me.RS_Exclure_ListBox.FormattingEnabled = True
        Me.RS_Exclure_ListBox.Location = New System.Drawing.Point(363, 73)
        Me.RS_Exclure_ListBox.Name = "RS_Exclure_ListBox"
        Me.RS_Exclure_ListBox.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.RS_Exclure_ListBox.Size = New System.Drawing.Size(207, 69)
        Me.RS_Exclure_ListBox.TabIndex = 16
        '
        'RS_Inclure_ListBox
        '
        Me.RS_Inclure_ListBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RS_Inclure_ListBox.ForeColor = System.Drawing.Color.ForestGreen
        Me.RS_Inclure_ListBox.FormattingEnabled = True
        Me.RS_Inclure_ListBox.Location = New System.Drawing.Point(153, 73)
        Me.RS_Inclure_ListBox.Name = "RS_Inclure_ListBox"
        Me.RS_Inclure_ListBox.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.RS_Inclure_ListBox.Size = New System.Drawing.Size(207, 69)
        Me.RS_Inclure_ListBox.TabIndex = 11
        '
        'RS_Exclure_Moin_Button
        '
        Me.RS_Exclure_Moin_Button.BackColor = System.Drawing.Color.White
        Me.RS_Exclure_Moin_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RS_Exclure_Moin_Button.Location = New System.Drawing.Point(503, 48)
        Me.RS_Exclure_Moin_Button.Name = "RS_Exclure_Moin_Button"
        Me.RS_Exclure_Moin_Button.Size = New System.Drawing.Size(20, 20)
        Me.RS_Exclure_Moin_Button.TabIndex = 15
        Me.RS_Exclure_Moin_Button.Text = "-"
        Me.RS_Exclure_Moin_Button.UseVisualStyleBackColor = False
        '
        'RS_Exclure_Plus_Button
        '
        Me.RS_Exclure_Plus_Button.BackColor = System.Drawing.Color.White
        Me.RS_Exclure_Plus_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RS_Exclure_Plus_Button.Location = New System.Drawing.Point(477, 48)
        Me.RS_Exclure_Plus_Button.Name = "RS_Exclure_Plus_Button"
        Me.RS_Exclure_Plus_Button.Size = New System.Drawing.Size(20, 20)
        Me.RS_Exclure_Plus_Button.TabIndex = 14
        Me.RS_Exclure_Plus_Button.Text = "+"
        Me.RS_Exclure_Plus_Button.UseVisualStyleBackColor = False
        '
        'RS_Inclure_Moin_Button
        '
        Me.RS_Inclure_Moin_Button.BackColor = System.Drawing.Color.White
        Me.RS_Inclure_Moin_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RS_Inclure_Moin_Button.Location = New System.Drawing.Point(292, 48)
        Me.RS_Inclure_Moin_Button.Name = "RS_Inclure_Moin_Button"
        Me.RS_Inclure_Moin_Button.Size = New System.Drawing.Size(20, 20)
        Me.RS_Inclure_Moin_Button.TabIndex = 10
        Me.RS_Inclure_Moin_Button.Text = "-"
        Me.RS_Inclure_Moin_Button.UseVisualStyleBackColor = False
        '
        'RS_Inclure_Plus_Button
        '
        Me.RS_Inclure_Plus_Button.BackColor = System.Drawing.Color.White
        Me.RS_Inclure_Plus_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RS_Inclure_Plus_Button.Location = New System.Drawing.Point(266, 48)
        Me.RS_Inclure_Plus_Button.Name = "RS_Inclure_Plus_Button"
        Me.RS_Inclure_Plus_Button.Size = New System.Drawing.Size(20, 20)
        Me.RS_Inclure_Plus_Button.TabIndex = 9
        Me.RS_Inclure_Plus_Button.Text = "+"
        Me.RS_Inclure_Plus_Button.UseVisualStyleBackColor = False
        '
        'RS_Exclure_Label
        '
        Me.RS_Exclure_Label.AutoSize = True
        Me.RS_Exclure_Label.BackColor = System.Drawing.Color.Transparent
        Me.RS_Exclure_Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RS_Exclure_Label.Location = New System.Drawing.Point(360, 47)
        Me.RS_Exclure_Label.Name = "RS_Exclure_Label"
        Me.RS_Exclure_Label.Size = New System.Drawing.Size(59, 16)
        Me.RS_Exclure_Label.TabIndex = 13
        Me.RS_Exclure_Label.Text = "Exclure"
        '
        'RS_Mot_Clef_Label
        '
        Me.RS_Mot_Clef_Label.AutoSize = True
        Me.RS_Mot_Clef_Label.BackColor = System.Drawing.Color.Transparent
        Me.RS_Mot_Clef_Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RS_Mot_Clef_Label.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RS_Mot_Clef_Label.Location = New System.Drawing.Point(3, 79)
        Me.RS_Mot_Clef_Label.Name = "RS_Mot_Clef_Label"
        Me.RS_Mot_Clef_Label.Size = New System.Drawing.Size(100, 16)
        Me.RS_Mot_Clef_Label.TabIndex = 4
        Me.RS_Mot_Clef_Label.Text = "Mot(s) Clef(s)"
        '
        'RS_Inclure_Label
        '
        Me.RS_Inclure_Label.AutoSize = True
        Me.RS_Inclure_Label.BackColor = System.Drawing.Color.Transparent
        Me.RS_Inclure_Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RS_Inclure_Label.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RS_Inclure_Label.Location = New System.Drawing.Point(153, 47)
        Me.RS_Inclure_Label.Name = "RS_Inclure_Label"
        Me.RS_Inclure_Label.Size = New System.Drawing.Size(54, 16)
        Me.RS_Inclure_Label.TabIndex = 8
        Me.RS_Inclure_Label.Text = "Inclure"
        '
        'RS_CheckBox
        '
        Me.RS_CheckBox.AutoSize = True
        Me.RS_CheckBox.BackColor = System.Drawing.Color.Transparent
        Me.RS_CheckBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RS_CheckBox.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RS_CheckBox.Location = New System.Drawing.Point(6, 119)
        Me.RS_CheckBox.Name = "RS_CheckBox"
        Me.RS_CheckBox.Size = New System.Drawing.Size(123, 20)
        Me.RS_CheckBox.TabIndex = 6
        Me.RS_CheckBox.Text = "Sch�ma Type"
        Me.RS_CheckBox.UseVisualStyleBackColor = False
        '
        'RS_NOM_ENREGISTREMENT
        '
        Me.RS_NOM_ENREGISTREMENT.Location = New System.Drawing.Point(6, 48)
        Me.RS_NOM_ENREGISTREMENT.Name = "RS_NOM_ENREGISTREMENT"
        Me.RS_NOM_ENREGISTREMENT.Size = New System.Drawing.Size(125, 20)
        Me.RS_NOM_ENREGISTREMENT.TabIndex = 3
        '
        'RS_Nom_Enregistrement_Label
        '
        Me.RS_Nom_Enregistrement_Label.AutoSize = True
        Me.RS_Nom_Enregistrement_Label.BackColor = System.Drawing.Color.Transparent
        Me.RS_Nom_Enregistrement_Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RS_Nom_Enregistrement_Label.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RS_Nom_Enregistrement_Label.Location = New System.Drawing.Point(3, 25)
        Me.RS_Nom_Enregistrement_Label.Name = "RS_Nom_Enregistrement_Label"
        Me.RS_Nom_Enregistrement_Label.Size = New System.Drawing.Size(112, 16)
        Me.RS_Nom_Enregistrement_Label.TabIndex = 2
        Me.RS_Nom_Enregistrement_Label.Text = "Enregistrement"
        '
        'Button_Recherche_Simplifi�e
        '
        Me.Button_Recherche_Simplifi�e.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button_Recherche_Simplifi�e.BackColor = System.Drawing.Color.Transparent
        Me.Button_Recherche_Simplifi�e.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Button_Recherche_Simplifi�e.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Recherche_Simplifi�e.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue
        Me.Button_Recherche_Simplifi�e.Location = New System.Drawing.Point(579, 73)
        Me.Button_Recherche_Simplifi�e.Name = "Button_Recherche_Simplifi�e"
        Me.Button_Recherche_Simplifi�e.Size = New System.Drawing.Size(114, 30)
        Me.Button_Recherche_Simplifi�e.TabIndex = 17
        Me.Button_Recherche_Simplifi�e.UseVisualStyleBackColor = False
        '
        'Button_Annuler_Recherche_Simplifi�e
        '
        Me.Button_Annuler_Recherche_Simplifi�e.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button_Annuler_Recherche_Simplifi�e.BackColor = System.Drawing.Color.Transparent
        Me.Button_Annuler_Recherche_Simplifi�e.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button_Annuler_Recherche_Simplifi�e.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Annuler_Recherche_Simplifi�e.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue
        Me.Button_Annuler_Recherche_Simplifi�e.Location = New System.Drawing.Point(579, 109)
        Me.Button_Annuler_Recherche_Simplifi�e.Name = "Button_Annuler_Recherche_Simplifi�e"
        Me.Button_Annuler_Recherche_Simplifi�e.Size = New System.Drawing.Size(114, 30)
        Me.Button_Annuler_Recherche_Simplifi�e.TabIndex = 18
        Me.Button_Annuler_Recherche_Simplifi�e.UseVisualStyleBackColor = False
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WebBrowser1.Location = New System.Drawing.Point(3, 3)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(955, 355)
        Me.WebBrowser1.TabIndex = 15
        Me.WebBrowser1.Url = New System.Uri("", System.UriKind.Relative)
        Me.WebBrowser1.Visible = False
        '
        'TableLayoutPanel_Image_RS
        '
        Me.TableLayoutPanel_Image_RS.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel_Image_RS.ColumnCount = 3
        Me.TableLayoutPanel_Image_RS.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel_Image_RS.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 579.0!))
        Me.TableLayoutPanel_Image_RS.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel_Image_RS.Controls.Add(Me.PictureBox_LOGO_RS, 1, 1)
        Me.TableLayoutPanel_Image_RS.Location = New System.Drawing.Point(-1, -1)
        Me.TableLayoutPanel_Image_RS.Name = "TableLayoutPanel_Image_RS"
        Me.TableLayoutPanel_Image_RS.RowCount = 3
        Me.TableLayoutPanel_Image_RS.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel_Image_RS.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 307.0!))
        Me.TableLayoutPanel_Image_RS.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel_Image_RS.Size = New System.Drawing.Size(958, 364)
        Me.TableLayoutPanel_Image_RS.TabIndex = 17
        '
        'PictureBox_LOGO_RS
        '
        Me.PictureBox_LOGO_RS.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox_LOGO_RS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox_LOGO_RS.Image = Global.IDEALTAKE.My.Resources.Resources.LOGO_V1
        Me.PictureBox_LOGO_RS.Location = New System.Drawing.Point(303, 99)
        Me.PictureBox_LOGO_RS.Name = "PictureBox_LOGO_RS"
        Me.PictureBox_LOGO_RS.Size = New System.Drawing.Size(350, 164)
        Me.PictureBox_LOGO_RS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox_LOGO_RS.TabIndex = 8
        Me.PictureBox_LOGO_RS.TabStop = False
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Transparent
        Me.TabPage1.BackgroundImage = CType(resources.GetObject("TabPage1.BackgroundImage"), System.Drawing.Image)
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage1.Controls.Add(Me.MenuStrip2)
        Me.TabPage1.Controls.Add(Me.TableLayoutPanel3)
        Me.TabPage1.Controls.Add(Me.WebBrowser2)
        Me.TabPage1.Controls.Add(Me.TableLayoutPanel_Image_RA)
        Me.TabPage1.ImageIndex = 2
        Me.TabPage1.Location = New System.Drawing.Point(4, 38)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(966, 530)
        Me.TabPage1.TabIndex = 2
        Me.TabPage1.Text = "Recherche Avanc�e"
        Me.TabPage1.ToolTipText = "Recherche un sch�ma par Cat�gorie"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem9})
        Me.MenuStrip2.Location = New System.Drawing.Point(17, 13)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip2.Size = New System.Drawing.Size(90, 24)
        Me.MenuStrip2.TabIndex = 14
        Me.MenuStrip2.Text = "MenuStrip2"
        Me.MenuStrip2.Visible = False
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem10, Me.ToolStripMenuItem11, Me.ToolStripMenuItem12})
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(82, 20)
        Me.ToolStripMenuItem9.Text = "Zoom 100%"
        '
        'ToolStripMenuItem10
        '
        Me.ToolStripMenuItem10.Name = "ToolStripMenuItem10"
        Me.ToolStripMenuItem10.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem10.Size = New System.Drawing.Size(178, 22)
        Me.ToolStripMenuItem10.Text = "Zoom +"
        '
        'ToolStripMenuItem11
        '
        Me.ToolStripMenuItem11.Name = "ToolStripMenuItem11"
        Me.ToolStripMenuItem11.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Alt) _
            Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem11.Size = New System.Drawing.Size(178, 22)
        Me.ToolStripMenuItem11.Text = "Zoom -"
        '
        'ToolStripMenuItem12
        '
        Me.ToolStripMenuItem12.Name = "ToolStripMenuItem12"
        Me.ToolStripMenuItem12.Size = New System.Drawing.Size(178, 22)
        Me.ToolStripMenuItem12.Text = "Reset Zoom"
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.TableLayoutPanel3.ColumnCount = 3
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 710.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.RA_GroupBox, 1, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 366)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(958, 159)
        Me.TableLayoutPanel3.TabIndex = 1
        '
        'RA_GroupBox
        '
        Me.RA_GroupBox.BackColor = System.Drawing.Color.LightCyan
        Me.RA_GroupBox.Controls.Add(Me.UserControl_RA_references)
        Me.RA_GroupBox.Controls.Add(Me.Documents_Disponibles)
        Me.RA_GroupBox.Controls.Add(Me.Documents_Recherch�es)
        Me.RA_GroupBox.Controls.Add(Me.Effacer_la_liste_de_documents)
        Me.RA_GroupBox.Controls.Add(Me.Ajouter_un_document)
        Me.RA_GroupBox.Controls.Add(Me.Label_PARAM_G_I)
        Me.RA_GroupBox.Controls.Add(Me.Label_PARAM_F_H)
        Me.RA_GroupBox.Controls.Add(Me.ComboBox_PARAM_I)
        Me.RA_GroupBox.Controls.Add(Me.Label_PARAM_I)
        Me.RA_GroupBox.Controls.Add(Me.ComboBox_PARAM_G)
        Me.RA_GroupBox.Controls.Add(Me.Label_PARAM_G)
        Me.RA_GroupBox.Controls.Add(Me.RA_CheckBox_1)
        Me.RA_GroupBox.Controls.Add(Me.ComboBox_PARAM_H)
        Me.RA_GroupBox.Controls.Add(Me.ComboBox_PARAM_F)
        Me.RA_GroupBox.Controls.Add(Me.RA_CheckBox_2)
        Me.RA_GroupBox.Controls.Add(Me.Button_Annuler_Recherche_Avanc�e)
        Me.RA_GroupBox.Controls.Add(Me.Label_PARAM_F)
        Me.RA_GroupBox.Controls.Add(Me.ComboBox_TABLE_E)
        Me.RA_GroupBox.Controls.Add(Me.ComboBox_TABLE_C)
        Me.RA_GroupBox.Controls.Add(Me.Label_TABLE_D)
        Me.RA_GroupBox.Controls.Add(Me.Label_TABLE_C)
        Me.RA_GroupBox.Controls.Add(Me.Button_Recherche_Avanc�e)
        Me.RA_GroupBox.Controls.Add(Me.Label_TABLE_E)
        Me.RA_GroupBox.Controls.Add(Me.ComboBox_TABLE_D)
        Me.RA_GroupBox.Controls.Add(Me.Label_TABLE_B)
        Me.RA_GroupBox.Controls.Add(Me.Label_PARAM_H)
        Me.RA_GroupBox.Controls.Add(Me.ComboBox_TABLE_B)
        Me.RA_GroupBox.Controls.Add(Me.Label_RA_REF)
        Me.RA_GroupBox.Controls.Add(Me.Label_TABLE_A)
        Me.RA_GroupBox.Controls.Add(Me.ComboBox_TABLE_A)
        Me.RA_GroupBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RA_GroupBox.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RA_GroupBox.Location = New System.Drawing.Point(127, 3)
        Me.RA_GroupBox.Name = "RA_GroupBox"
        Me.RA_GroupBox.Size = New System.Drawing.Size(704, 153)
        Me.RA_GroupBox.TabIndex = 1
        Me.RA_GroupBox.TabStop = False
        '
        'UserControl_RA_references
        '
        Me.UserControl_RA_references.BackColor = System.Drawing.Color.Transparent
        Me.UserControl_RA_references.Location = New System.Drawing.Point(223, 124)
        Me.UserControl_RA_references.Name = "UserControl_RA_references"
        Me.UserControl_RA_references.Size = New System.Drawing.Size(193, 25)
        Me.UserControl_RA_references.TabIndex = 82
        '
        'Documents_Disponibles
        '
        Me.Documents_Disponibles.ContextMenuStrip = Me.ContextMenuStrip2
        Me.Documents_Disponibles.DataBindings.Add(New System.Windows.Forms.Binding("ForeColor", Global.IDEALTAKE.My.MySettings.Default, "Couleur_Font", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Documents_Disponibles.ForeColor = Global.IDEALTAKE.My.MySettings.Default.Couleur_Font
        Me.Documents_Disponibles.FormattingEnabled = True
        Me.Documents_Disponibles.Location = New System.Drawing.Point(4, 11)
        Me.Documents_Disponibles.Margin = New System.Windows.Forms.Padding(2)
        Me.Documents_Disponibles.Name = "Documents_Disponibles"
        Me.Documents_Disponibles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.Documents_Disponibles.Size = New System.Drawing.Size(125, 56)
        Me.Documents_Disponibles.TabIndex = 78
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.DataBindings.Add(New System.Windows.Forms.Binding("ForeColor", Global.IDEALTAKE.My.MySettings.Default, "Couleur_Font", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.ContextMenuStrip2.ForeColor = Global.IDEALTAKE.My.MySettings.Default.Couleur_Font
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem39})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(114, 26)
        '
        'ToolStripMenuItem39
        '
        Me.ToolStripMenuItem39.Name = "ToolStripMenuItem39"
        Me.ToolStripMenuItem39.Size = New System.Drawing.Size(113, 22)
        Me.ToolStripMenuItem39.Text = "Ajouter"
        '
        'Documents_Recherch�es
        '
        Me.Documents_Recherch�es.AllowDrop = True
        Me.Documents_Recherch�es.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Documents_Recherch�es.ForeColor = System.Drawing.Color.ForestGreen
        Me.Documents_Recherch�es.FormattingEnabled = True
        Me.Documents_Recherch�es.Location = New System.Drawing.Point(4, 93)
        Me.Documents_Recherch�es.Margin = New System.Windows.Forms.Padding(2)
        Me.Documents_Recherch�es.Name = "Documents_Recherch�es"
        Me.Documents_Recherch�es.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.Documents_Recherch�es.Size = New System.Drawing.Size(125, 56)
        Me.Documents_Recherch�es.Sorted = True
        Me.Documents_Recherch�es.TabIndex = 81
        '
        'Effacer_la_liste_de_documents
        '
        Me.Effacer_la_liste_de_documents.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Effacer_la_liste_de_documents.Location = New System.Drawing.Point(78, 70)
        Me.Effacer_la_liste_de_documents.Margin = New System.Windows.Forms.Padding(2)
        Me.Effacer_la_liste_de_documents.Name = "Effacer_la_liste_de_documents"
        Me.Effacer_la_liste_de_documents.Size = New System.Drawing.Size(51, 19)
        Me.Effacer_la_liste_de_documents.TabIndex = 80
        Me.Effacer_la_liste_de_documents.Text = "Effacer"
        Me.Effacer_la_liste_de_documents.UseVisualStyleBackColor = False
        '
        'Ajouter_un_document
        '
        Me.Ajouter_un_document.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Ajouter_un_document.Image = Global.IDEALTAKE.My.Resources.Resources.Fl�che_verte_pointant_vers_le_bas_v4_11x13
        Me.Ajouter_un_document.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Ajouter_un_document.Location = New System.Drawing.Point(4, 70)
        Me.Ajouter_un_document.Margin = New System.Windows.Forms.Padding(2)
        Me.Ajouter_un_document.Name = "Ajouter_un_document"
        Me.Ajouter_un_document.Size = New System.Drawing.Size(70, 19)
        Me.Ajouter_un_document.TabIndex = 79
        Me.Ajouter_un_document.Text = "Ajouter"
        Me.Ajouter_un_document.UseVisualStyleBackColor = False
        '
        'Label_PARAM_G_I
        '
        Me.Label_PARAM_G_I.AutoSize = True
        Me.Label_PARAM_G_I.BackColor = System.Drawing.Color.Transparent
        Me.Label_PARAM_G_I.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_PARAM_G_I.Location = New System.Drawing.Point(644, 43)
        Me.Label_PARAM_G_I.Name = "Label_PARAM_G_I"
        Me.Label_PARAM_G_I.Size = New System.Drawing.Size(34, 13)
        Me.Label_PARAM_G_I.TabIndex = 77
        Me.Label_PARAM_G_I.Text = "Vid�o"
        '
        'Label_PARAM_F_H
        '
        Me.Label_PARAM_F_H.AutoSize = True
        Me.Label_PARAM_F_H.BackColor = System.Drawing.Color.Transparent
        Me.Label_PARAM_F_H.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_PARAM_F_H.Location = New System.Drawing.Point(551, 43)
        Me.Label_PARAM_F_H.Name = "Label_PARAM_F_H"
        Me.Label_PARAM_F_H.Size = New System.Drawing.Size(34, 13)
        Me.Label_PARAM_F_H.TabIndex = 76
        Me.Label_PARAM_F_H.Text = "Audio"
        '
        'ComboBox_PARAM_I
        '
        Me.ComboBox_PARAM_I.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComboBox_PARAM_I.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_PARAM_I.FormattingEnabled = True
        Me.ComboBox_PARAM_I.Items.AddRange(New Object() {"", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"})
        Me.ComboBox_PARAM_I.Location = New System.Drawing.Point(641, 83)
        Me.ComboBox_PARAM_I.Name = "ComboBox_PARAM_I"
        Me.ComboBox_PARAM_I.Size = New System.Drawing.Size(40, 21)
        Me.ComboBox_PARAM_I.TabIndex = 74
        '
        'Label_PARAM_I
        '
        Me.Label_PARAM_I.AutoSize = True
        Me.Label_PARAM_I.BackColor = System.Drawing.Color.Transparent
        Me.Label_PARAM_I.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_PARAM_I.Location = New System.Drawing.Point(593, 84)
        Me.Label_PARAM_I.Name = "Label_PARAM_I"
        Me.Label_PARAM_I.Size = New System.Drawing.Size(0, 13)
        Me.Label_PARAM_I.TabIndex = 75
        '
        'ComboBox_PARAM_G
        '
        Me.ComboBox_PARAM_G.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComboBox_PARAM_G.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_PARAM_G.FormattingEnabled = True
        Me.ComboBox_PARAM_G.Items.AddRange(New Object() {"", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"})
        Me.ComboBox_PARAM_G.Location = New System.Drawing.Point(641, 59)
        Me.ComboBox_PARAM_G.Name = "ComboBox_PARAM_G"
        Me.ComboBox_PARAM_G.Size = New System.Drawing.Size(40, 21)
        Me.ComboBox_PARAM_G.TabIndex = 72
        '
        'Label_PARAM_G
        '
        Me.Label_PARAM_G.AutoSize = True
        Me.Label_PARAM_G.BackColor = System.Drawing.Color.Transparent
        Me.Label_PARAM_G.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_PARAM_G.Location = New System.Drawing.Point(593, 61)
        Me.Label_PARAM_G.Name = "Label_PARAM_G"
        Me.Label_PARAM_G.Size = New System.Drawing.Size(0, 13)
        Me.Label_PARAM_G.TabIndex = 73
        '
        'RA_CheckBox_1
        '
        Me.RA_CheckBox_1.AutoSize = True
        Me.RA_CheckBox_1.BackColor = System.Drawing.Color.Transparent
        Me.RA_CheckBox_1.Checked = True
        Me.RA_CheckBox_1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.RA_CheckBox_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RA_CheckBox_1.Location = New System.Drawing.Point(420, 109)
        Me.RA_CheckBox_1.Name = "RA_CheckBox_1"
        Me.RA_CheckBox_1.Size = New System.Drawing.Size(84, 17)
        Me.RA_CheckBox_1.TabIndex = 6
        Me.RA_CheckBox_1.Text = "Avec Portier"
        Me.RA_CheckBox_1.UseVisualStyleBackColor = False
        '
        'ComboBox_PARAM_H
        '
        Me.ComboBox_PARAM_H.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComboBox_PARAM_H.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_PARAM_H.FormattingEnabled = True
        Me.ComboBox_PARAM_H.Items.AddRange(New Object() {"", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"})
        Me.ComboBox_PARAM_H.Location = New System.Drawing.Point(548, 83)
        Me.ComboBox_PARAM_H.Name = "ComboBox_PARAM_H"
        Me.ComboBox_PARAM_H.Size = New System.Drawing.Size(40, 21)
        Me.ComboBox_PARAM_H.TabIndex = 11
        '
        'ComboBox_PARAM_F
        '
        Me.ComboBox_PARAM_F.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComboBox_PARAM_F.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_PARAM_F.FormattingEnabled = True
        Me.ComboBox_PARAM_F.Items.AddRange(New Object() {"", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"})
        Me.ComboBox_PARAM_F.Location = New System.Drawing.Point(548, 59)
        Me.ComboBox_PARAM_F.Name = "ComboBox_PARAM_F"
        Me.ComboBox_PARAM_F.Size = New System.Drawing.Size(40, 21)
        Me.ComboBox_PARAM_F.TabIndex = 10
        '
        'RA_CheckBox_2
        '
        Me.RA_CheckBox_2.AutoSize = True
        Me.RA_CheckBox_2.BackColor = System.Drawing.Color.Transparent
        Me.RA_CheckBox_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RA_CheckBox_2.Location = New System.Drawing.Point(420, 126)
        Me.RA_CheckBox_2.Name = "RA_CheckBox_2"
        Me.RA_CheckBox_2.Size = New System.Drawing.Size(92, 17)
        Me.RA_CheckBox_2.TabIndex = 5
        Me.RA_CheckBox_2.Text = "Sch�ma Type"
        Me.RA_CheckBox_2.UseVisualStyleBackColor = False
        '
        'Button_Annuler_Recherche_Avanc�e
        '
        Me.Button_Annuler_Recherche_Avanc�e.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button_Annuler_Recherche_Avanc�e.BackColor = System.Drawing.Color.Transparent
        Me.Button_Annuler_Recherche_Avanc�e.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Annuler_Recherche_Avanc�e.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue1
        Me.Button_Annuler_Recherche_Avanc�e.Location = New System.Drawing.Point(612, 113)
        Me.Button_Annuler_Recherche_Avanc�e.Name = "Button_Annuler_Recherche_Avanc�e"
        Me.Button_Annuler_Recherche_Avanc�e.Size = New System.Drawing.Size(90, 30)
        Me.Button_Annuler_Recherche_Avanc�e.TabIndex = 16
        Me.Button_Annuler_Recherche_Avanc�e.UseVisualStyleBackColor = False
        '
        'Label_PARAM_F
        '
        Me.Label_PARAM_F.AutoSize = True
        Me.Label_PARAM_F.BackColor = System.Drawing.Color.Transparent
        Me.Label_PARAM_F.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_PARAM_F.Location = New System.Drawing.Point(468, 58)
        Me.Label_PARAM_F.Name = "Label_PARAM_F"
        Me.Label_PARAM_F.Size = New System.Drawing.Size(67, 13)
        Me.Label_PARAM_F.TabIndex = 25
        Me.Label_PARAM_F.Text = " Principale(s)"
        '
        'ComboBox_TABLE_E
        '
        Me.ComboBox_TABLE_E.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComboBox_TABLE_E.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_TABLE_E.FormattingEnabled = True
        Me.ComboBox_TABLE_E.Location = New System.Drawing.Point(223, 75)
        Me.ComboBox_TABLE_E.Name = "ComboBox_TABLE_E"
        Me.ComboBox_TABLE_E.Size = New System.Drawing.Size(194, 21)
        Me.ComboBox_TABLE_E.TabIndex = 12
        '
        'ComboBox_TABLE_C
        '
        Me.ComboBox_TABLE_C.AccessibleDescription = ""
        Me.ComboBox_TABLE_C.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComboBox_TABLE_C.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_TABLE_C.FormattingEnabled = True
        Me.ComboBox_TABLE_C.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.ComboBox_TABLE_C.Location = New System.Drawing.Point(223, 20)
        Me.ComboBox_TABLE_C.Name = "ComboBox_TABLE_C"
        Me.ComboBox_TABLE_C.Size = New System.Drawing.Size(194, 21)
        Me.ComboBox_TABLE_C.TabIndex = 7
        '
        'Label_TABLE_D
        '
        Me.Label_TABLE_D.AutoSize = True
        Me.Label_TABLE_D.BackColor = System.Drawing.Color.Transparent
        Me.Label_TABLE_D.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_TABLE_D.Location = New System.Drawing.Point(468, 23)
        Me.Label_TABLE_D.Name = "Label_TABLE_D"
        Me.Label_TABLE_D.Size = New System.Drawing.Size(31, 13)
        Me.Label_TABLE_D.TabIndex = 70
        Me.Label_TABLE_D.Text = "S�rie"
        '
        'Label_TABLE_C
        '
        Me.Label_TABLE_C.AutoSize = True
        Me.Label_TABLE_C.BackColor = System.Drawing.Color.Transparent
        Me.Label_TABLE_C.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_TABLE_C.Location = New System.Drawing.Point(133, 23)
        Me.Label_TABLE_C.Name = "Label_TABLE_C"
        Me.Label_TABLE_C.Size = New System.Drawing.Size(47, 13)
        Me.Label_TABLE_C.TabIndex = 20
        Me.Label_TABLE_C.Text = "Syst�me"
        '
        'Button_Recherche_Avanc�e
        '
        Me.Button_Recherche_Avanc�e.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button_Recherche_Avanc�e.BackColor = System.Drawing.Color.Transparent
        Me.Button_Recherche_Avanc�e.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Recherche_Avanc�e.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue1
        Me.Button_Recherche_Avanc�e.Location = New System.Drawing.Point(513, 113)
        Me.Button_Recherche_Avanc�e.Name = "Button_Recherche_Avanc�e"
        Me.Button_Recherche_Avanc�e.Size = New System.Drawing.Size(100, 30)
        Me.Button_Recherche_Avanc�e.TabIndex = 15
        Me.Button_Recherche_Avanc�e.UseVisualStyleBackColor = False
        '
        'Label_TABLE_E
        '
        Me.Label_TABLE_E.AutoSize = True
        Me.Label_TABLE_E.BackColor = System.Drawing.Color.Transparent
        Me.Label_TABLE_E.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_TABLE_E.Location = New System.Drawing.Point(133, 78)
        Me.Label_TABLE_E.Name = "Label_TABLE_E"
        Me.Label_TABLE_E.Size = New System.Drawing.Size(86, 13)
        Me.Label_TABLE_E.TabIndex = 21
        Me.Label_TABLE_E.Text = "Contr�le d'acces"
        '
        'ComboBox_TABLE_D
        '
        Me.ComboBox_TABLE_D.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComboBox_TABLE_D.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_TABLE_D.FormattingEnabled = True
        Me.ComboBox_TABLE_D.Location = New System.Drawing.Point(516, 20)
        Me.ComboBox_TABLE_D.Name = "ComboBox_TABLE_D"
        Me.ComboBox_TABLE_D.Size = New System.Drawing.Size(180, 21)
        Me.ComboBox_TABLE_D.TabIndex = 9
        '
        'Label_TABLE_B
        '
        Me.Label_TABLE_B.AutoSize = True
        Me.Label_TABLE_B.BackColor = System.Drawing.Color.Transparent
        Me.Label_TABLE_B.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_TABLE_B.Location = New System.Drawing.Point(133, 51)
        Me.Label_TABLE_B.Name = "Label_TABLE_B"
        Me.Label_TABLE_B.Size = New System.Drawing.Size(66, 13)
        Me.Label_TABLE_B.TabIndex = 23
        Me.Label_TABLE_B.Text = "Audio/Vid�o"
        '
        'Label_PARAM_H
        '
        Me.Label_PARAM_H.AutoSize = True
        Me.Label_PARAM_H.BackColor = System.Drawing.Color.Transparent
        Me.Label_PARAM_H.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_PARAM_H.Location = New System.Drawing.Point(470, 85)
        Me.Label_PARAM_H.Name = "Label_PARAM_H"
        Me.Label_PARAM_H.Size = New System.Drawing.Size(72, 13)
        Me.Label_PARAM_H.TabIndex = 30
        Me.Label_PARAM_H.Text = "Secondaire(s)"
        '
        'ComboBox_TABLE_B
        '
        Me.ComboBox_TABLE_B.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComboBox_TABLE_B.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_TABLE_B.FormattingEnabled = True
        Me.ComboBox_TABLE_B.Location = New System.Drawing.Point(223, 48)
        Me.ComboBox_TABLE_B.Name = "ComboBox_TABLE_B"
        Me.ComboBox_TABLE_B.Size = New System.Drawing.Size(194, 21)
        Me.ComboBox_TABLE_B.TabIndex = 8
        '
        'Label_RA_REF
        '
        Me.Label_RA_REF.AutoSize = True
        Me.Label_RA_REF.BackColor = System.Drawing.Color.Transparent
        Me.Label_RA_REF.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_RA_REF.Location = New System.Drawing.Point(133, 128)
        Me.Label_RA_REF.Name = "Label_RA_REF"
        Me.Label_RA_REF.Size = New System.Drawing.Size(57, 13)
        Me.Label_RA_REF.TabIndex = 31
        Me.Label_RA_REF.Text = "R�f�rence"
        '
        'Label_TABLE_A
        '
        Me.Label_TABLE_A.AutoSize = True
        Me.Label_TABLE_A.BackColor = System.Drawing.Color.Transparent
        Me.Label_TABLE_A.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_TABLE_A.Location = New System.Drawing.Point(133, 104)
        Me.Label_TABLE_A.Name = "Label_TABLE_A"
        Me.Label_TABLE_A.Size = New System.Drawing.Size(62, 13)
        Me.Label_TABLE_A.TabIndex = 28
        Me.Label_TABLE_A.Text = "V�rrouillage"
        '
        'ComboBox_TABLE_A
        '
        Me.ComboBox_TABLE_A.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComboBox_TABLE_A.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_TABLE_A.FormattingEnabled = True
        Me.ComboBox_TABLE_A.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.ComboBox_TABLE_A.Location = New System.Drawing.Point(223, 99)
        Me.ComboBox_TABLE_A.Name = "ComboBox_TABLE_A"
        Me.ComboBox_TABLE_A.Size = New System.Drawing.Size(194, 21)
        Me.ComboBox_TABLE_A.TabIndex = 13
        '
        'WebBrowser2
        '
        Me.WebBrowser2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WebBrowser2.Location = New System.Drawing.Point(3, 3)
        Me.WebBrowser2.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser2.Name = "WebBrowser2"
        Me.WebBrowser2.Size = New System.Drawing.Size(955, 355)
        Me.WebBrowser2.TabIndex = 2
        Me.WebBrowser2.Url = New System.Uri("", System.UriKind.Relative)
        Me.WebBrowser2.Visible = False
        '
        'TableLayoutPanel_Image_RA
        '
        Me.TableLayoutPanel_Image_RA.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel_Image_RA.ColumnCount = 3
        Me.TableLayoutPanel_Image_RA.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel_Image_RA.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 579.0!))
        Me.TableLayoutPanel_Image_RA.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel_Image_RA.Controls.Add(Me.PictureBox_LOGO_RA, 1, 1)
        Me.TableLayoutPanel_Image_RA.Location = New System.Drawing.Point(-1, -1)
        Me.TableLayoutPanel_Image_RA.Name = "TableLayoutPanel_Image_RA"
        Me.TableLayoutPanel_Image_RA.RowCount = 3
        Me.TableLayoutPanel_Image_RA.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel_Image_RA.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 307.0!))
        Me.TableLayoutPanel_Image_RA.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel_Image_RA.Size = New System.Drawing.Size(958, 364)
        Me.TableLayoutPanel_Image_RA.TabIndex = 18
        '
        'PictureBox_LOGO_RA
        '
        Me.PictureBox_LOGO_RA.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox_LOGO_RA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox_LOGO_RA.Image = Global.IDEALTAKE.My.Resources.Resources.LOGO_V11
        Me.PictureBox_LOGO_RA.Location = New System.Drawing.Point(303, 99)
        Me.PictureBox_LOGO_RA.Name = "PictureBox_LOGO_RA"
        Me.PictureBox_LOGO_RA.Size = New System.Drawing.Size(350, 164)
        Me.PictureBox_LOGO_RA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox_LOGO_RA.TabIndex = 10
        Me.PictureBox_LOGO_RA.TabStop = False
        '
        'TabPage7
        '
        Me.TabPage7.BackgroundImage = Global.IDEALTAKE.My.Resources.Resources.Pict0017j
        Me.TabPage7.Controls.Add(Me.SplitContainer1)
        Me.TabPage7.ImageIndex = 3
        Me.TabPage7.Location = New System.Drawing.Point(4, 38)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(966, 530)
        Me.TabPage7.TabIndex = 0
        Me.TabPage7.Text = "Recherche Guid�e"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Margin = New System.Windows.Forms.Padding(2)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.Recherche_guid�e_TreeView)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.WebBrowser3)
        Me.SplitContainer1.Size = New System.Drawing.Size(966, 530)
        Me.SplitContainer1.SplitterDistance = 320
        Me.SplitContainer1.SplitterWidth = 3
        Me.SplitContainer1.TabIndex = 0
        '
        'Recherche_guid�e_TreeView
        '
        Me.Recherche_guid�e_TreeView.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Recherche_guid�e_TreeView.DataBindings.Add(New System.Windows.Forms.Binding("ForeColor", Global.IDEALTAKE.My.MySettings.Default, "Couleur_Font", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Recherche_guid�e_TreeView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Recherche_guid�e_TreeView.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Recherche_guid�e_TreeView.ForeColor = Global.IDEALTAKE.My.MySettings.Default.Couleur_Font
        Me.Recherche_guid�e_TreeView.Location = New System.Drawing.Point(0, 0)
        Me.Recherche_guid�e_TreeView.Margin = New System.Windows.Forms.Padding(2)
        Me.Recherche_guid�e_TreeView.Name = "Recherche_guid�e_TreeView"
        Me.Recherche_guid�e_TreeView.Size = New System.Drawing.Size(320, 530)
        Me.Recherche_guid�e_TreeView.TabIndex = 0
        '
        'WebBrowser3
        '
        Me.WebBrowser3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser3.Location = New System.Drawing.Point(0, 0)
        Me.WebBrowser3.Margin = New System.Windows.Forms.Padding(2)
        Me.WebBrowser3.MinimumSize = New System.Drawing.Size(15, 16)
        Me.WebBrowser3.Name = "WebBrowser3"
        Me.WebBrowser3.Size = New System.Drawing.Size(643, 530)
        Me.WebBrowser3.TabIndex = 0
        Me.WebBrowser3.Visible = False
        '
        'TabPage5
        '
        Me.TabPage5.BackgroundImage = CType(resources.GetObject("TabPage5.BackgroundImage"), System.Drawing.Image)
        Me.TabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage5.Controls.Add(Me.PictureBox_LOGO_Statistiques)
        Me.TabPage5.Controls.Add(Me.TableLayoutPanel4)
        Me.TabPage5.Controls.Add(Me.TableLayoutPanel5)
        Me.TabPage5.ImageIndex = 4
        Me.TabPage5.Location = New System.Drawing.Point(4, 38)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(966, 530)
        Me.TabPage5.TabIndex = 5
        Me.TabPage5.Text = "Statistiques"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'PictureBox_LOGO_Statistiques
        '
        Me.PictureBox_LOGO_Statistiques.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox_LOGO_Statistiques.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox_LOGO_Statistiques.Image = Global.IDEALTAKE.My.Resources.Resources.LOGO_V1
        Me.PictureBox_LOGO_Statistiques.Location = New System.Drawing.Point(315, 70)
        Me.PictureBox_LOGO_Statistiques.Name = "PictureBox_LOGO_Statistiques"
        Me.PictureBox_LOGO_Statistiques.Size = New System.Drawing.Size(350, 164)
        Me.PictureBox_LOGO_Statistiques.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox_LOGO_Statistiques.TabIndex = 11
        Me.PictureBox_LOGO_Statistiques.TabStop = False
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel4.ColumnCount = 3
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 710.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.GROUP_STATISTIQUE, 1, 0)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(0, 369)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 1
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 159.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(964, 159)
        Me.TableLayoutPanel4.TabIndex = 12
        '
        'GROUP_STATISTIQUE
        '
        Me.GROUP_STATISTIQUE.BackColor = System.Drawing.Color.LightCyan
        Me.GROUP_STATISTIQUE.Controls.Add(Me.PictureBox_Statistique_commun_verticale_droite)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.PictureBox_Statistique_commun_horizontale)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.PictureBox_Statistique_commun_verticale_gauche)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Bordure_Statistique_Milieu_Verticale)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Bordure_Statistique_Droite)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Bordure_Statistique_Gauche)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Bordure_Statistique_Basse)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Bordure_Statistique_Haute)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Button_Statistique_Enregistrer_Rapport)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.TextBox_Statistique_nom_du_rapport_�_sauver)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Label_Statistique_Nom_du_rapport_a_sauver)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Button_Statistique_S�lection_Imprimante)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Button_Statistique_Imprime_un_rapport_Sauvegard�)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Button_Statistique_Effacer_la_recherche)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Button_Statistique_Suppression_Rapport_Sauvegard�)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Label_Statistique_Rapports_Sauvegard�s)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Label_Statistique_Code_Document)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.TextBox_Statistique_CODE_SCHEMA)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.ComboBox_Statistique_Type_recherche)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Label_Statistique_Selection)
        Me.GROUP_STATISTIQUE.Controls.Add(Me.Button_Statistique_Visualiser_la_recherche)
        Me.GROUP_STATISTIQUE.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GROUP_STATISTIQUE.Location = New System.Drawing.Point(130, 3)
        Me.GROUP_STATISTIQUE.Name = "GROUP_STATISTIQUE"
        Me.GROUP_STATISTIQUE.Size = New System.Drawing.Size(704, 153)
        Me.GROUP_STATISTIQUE.TabIndex = 4
        Me.GROUP_STATISTIQUE.TabStop = False
        '
        'PictureBox_Statistique_commun_verticale_droite
        '
        Me.PictureBox_Statistique_commun_verticale_droite.BackColor = System.Drawing.Color.DarkGray
        Me.PictureBox_Statistique_commun_verticale_droite.Location = New System.Drawing.Point(490, 100)
        Me.PictureBox_Statistique_commun_verticale_droite.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox_Statistique_commun_verticale_droite.Name = "PictureBox_Statistique_commun_verticale_droite"
        Me.PictureBox_Statistique_commun_verticale_droite.Size = New System.Drawing.Size(4, 37)
        Me.PictureBox_Statistique_commun_verticale_droite.TabIndex = 29
        Me.PictureBox_Statistique_commun_verticale_droite.TabStop = False
        '
        'PictureBox_Statistique_commun_horizontale
        '
        Me.PictureBox_Statistique_commun_horizontale.BackColor = System.Drawing.Color.DarkGray
        Me.PictureBox_Statistique_commun_horizontale.Location = New System.Drawing.Point(208, 98)
        Me.PictureBox_Statistique_commun_horizontale.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox_Statistique_commun_horizontale.Name = "PictureBox_Statistique_commun_horizontale"
        Me.PictureBox_Statistique_commun_horizontale.Size = New System.Drawing.Size(285, 4)
        Me.PictureBox_Statistique_commun_horizontale.TabIndex = 28
        Me.PictureBox_Statistique_commun_horizontale.TabStop = False
        '
        'PictureBox_Statistique_commun_verticale_gauche
        '
        Me.PictureBox_Statistique_commun_verticale_gauche.BackColor = System.Drawing.Color.DarkGray
        Me.PictureBox_Statistique_commun_verticale_gauche.Location = New System.Drawing.Point(208, 99)
        Me.PictureBox_Statistique_commun_verticale_gauche.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox_Statistique_commun_verticale_gauche.Name = "PictureBox_Statistique_commun_verticale_gauche"
        Me.PictureBox_Statistique_commun_verticale_gauche.Size = New System.Drawing.Size(4, 37)
        Me.PictureBox_Statistique_commun_verticale_gauche.TabIndex = 27
        Me.PictureBox_Statistique_commun_verticale_gauche.TabStop = False
        '
        'Bordure_Statistique_Milieu_Verticale
        '
        Me.Bordure_Statistique_Milieu_Verticale.BackColor = System.Drawing.Color.DarkGray
        Me.Bordure_Statistique_Milieu_Verticale.Location = New System.Drawing.Point(346, 15)
        Me.Bordure_Statistique_Milieu_Verticale.Margin = New System.Windows.Forms.Padding(2)
        Me.Bordure_Statistique_Milieu_Verticale.Name = "Bordure_Statistique_Milieu_Verticale"
        Me.Bordure_Statistique_Milieu_Verticale.Size = New System.Drawing.Size(4, 77)
        Me.Bordure_Statistique_Milieu_Verticale.TabIndex = 24
        Me.Bordure_Statistique_Milieu_Verticale.TabStop = False
        '
        'Bordure_Statistique_Droite
        '
        Me.Bordure_Statistique_Droite.BackColor = System.Drawing.Color.DarkGray
        Me.Bordure_Statistique_Droite.Location = New System.Drawing.Point(692, 9)
        Me.Bordure_Statistique_Droite.Margin = New System.Windows.Forms.Padding(2)
        Me.Bordure_Statistique_Droite.Name = "Bordure_Statistique_Droite"
        Me.Bordure_Statistique_Droite.Size = New System.Drawing.Size(4, 138)
        Me.Bordure_Statistique_Droite.TabIndex = 22
        Me.Bordure_Statistique_Droite.TabStop = False
        '
        'Bordure_Statistique_Gauche
        '
        Me.Bordure_Statistique_Gauche.BackColor = System.Drawing.Color.DarkGray
        Me.Bordure_Statistique_Gauche.Location = New System.Drawing.Point(8, 9)
        Me.Bordure_Statistique_Gauche.Margin = New System.Windows.Forms.Padding(2)
        Me.Bordure_Statistique_Gauche.Name = "Bordure_Statistique_Gauche"
        Me.Bordure_Statistique_Gauche.Size = New System.Drawing.Size(4, 138)
        Me.Bordure_Statistique_Gauche.TabIndex = 21
        Me.Bordure_Statistique_Gauche.TabStop = False
        '
        'Bordure_Statistique_Basse
        '
        Me.Bordure_Statistique_Basse.BackColor = System.Drawing.Color.DarkGray
        Me.Bordure_Statistique_Basse.Location = New System.Drawing.Point(5, 141)
        Me.Bordure_Statistique_Basse.Margin = New System.Windows.Forms.Padding(2)
        Me.Bordure_Statistique_Basse.Name = "Bordure_Statistique_Basse"
        Me.Bordure_Statistique_Basse.Size = New System.Drawing.Size(694, 4)
        Me.Bordure_Statistique_Basse.TabIndex = 20
        Me.Bordure_Statistique_Basse.TabStop = False
        '
        'Bordure_Statistique_Haute
        '
        Me.Bordure_Statistique_Haute.BackColor = System.Drawing.Color.DarkGray
        Me.Bordure_Statistique_Haute.Location = New System.Drawing.Point(5, 11)
        Me.Bordure_Statistique_Haute.Margin = New System.Windows.Forms.Padding(2)
        Me.Bordure_Statistique_Haute.Name = "Bordure_Statistique_Haute"
        Me.Bordure_Statistique_Haute.Size = New System.Drawing.Size(694, 4)
        Me.Bordure_Statistique_Haute.TabIndex = 19
        Me.Bordure_Statistique_Haute.TabStop = False
        '
        'Button_Statistique_Enregistrer_Rapport
        '
        Me.Button_Statistique_Enregistrer_Rapport.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button_Statistique_Enregistrer_Rapport.BackColor = System.Drawing.Color.Transparent
        Me.Button_Statistique_Enregistrer_Rapport.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Statistique_Enregistrer_Rapport.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue1
        Me.Button_Statistique_Enregistrer_Rapport.Location = New System.Drawing.Point(113, 106)
        Me.Button_Statistique_Enregistrer_Rapport.Name = "Button_Statistique_Enregistrer_Rapport"
        Me.Button_Statistique_Enregistrer_Rapport.Size = New System.Drawing.Size(90, 30)
        Me.Button_Statistique_Enregistrer_Rapport.TabIndex = 6
        Me.Button_Statistique_Enregistrer_Rapport.Text = "Enregistrer"
        Me.ToolTip1.SetToolTip(Me.Button_Statistique_Enregistrer_Rapport, "Enregistre le r�sultat en cours de visualisation")
        Me.Button_Statistique_Enregistrer_Rapport.UseVisualStyleBackColor = False
        '
        'TextBox_Statistique_nom_du_rapport_�_sauver
        '
        Me.TextBox_Statistique_nom_du_rapport_�_sauver.Location = New System.Drawing.Point(206, 71)
        Me.TextBox_Statistique_nom_du_rapport_�_sauver.Name = "TextBox_Statistique_nom_du_rapport_�_sauver"
        Me.TextBox_Statistique_nom_du_rapport_�_sauver.Size = New System.Drawing.Size(135, 20)
        Me.TextBox_Statistique_nom_du_rapport_�_sauver.TabIndex = 5
        '
        'Label_Statistique_Nom_du_rapport_a_sauver
        '
        Me.Label_Statistique_Nom_du_rapport_a_sauver.AutoSize = True
        Me.Label_Statistique_Nom_du_rapport_a_sauver.BackColor = System.Drawing.Color.Transparent
        Me.Label_Statistique_Nom_du_rapport_a_sauver.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_Statistique_Nom_du_rapport_a_sauver.Location = New System.Drawing.Point(15, 73)
        Me.Label_Statistique_Nom_du_rapport_a_sauver.Name = "Label_Statistique_Nom_du_rapport_a_sauver"
        Me.Label_Statistique_Nom_du_rapport_a_sauver.Size = New System.Drawing.Size(124, 13)
        Me.Label_Statistique_Nom_du_rapport_a_sauver.TabIndex = 8
        Me.Label_Statistique_Nom_du_rapport_a_sauver.Text = "Nom du rapport � sauver"
        '
        'Button_Statistique_S�lection_Imprimante
        '
        Me.Button_Statistique_S�lection_Imprimante.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button_Statistique_S�lection_Imprimante.BackColor = System.Drawing.Color.Transparent
        Me.Button_Statistique_S�lection_Imprimante.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Statistique_S�lection_Imprimante.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue1
        Me.Button_Statistique_S�lection_Imprimante.Location = New System.Drawing.Point(397, 106)
        Me.Button_Statistique_S�lection_Imprimante.Name = "Button_Statistique_S�lection_Imprimante"
        Me.Button_Statistique_S�lection_Imprimante.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button_Statistique_S�lection_Imprimante.Size = New System.Drawing.Size(90, 30)
        Me.Button_Statistique_S�lection_Imprimante.TabIndex = 11
        Me.Button_Statistique_S�lection_Imprimante.Text = "Imprimante"
        Me.ToolTip1.SetToolTip(Me.Button_Statistique_S�lection_Imprimante, "S�lectionnez l'imprimante")
        Me.Button_Statistique_S�lection_Imprimante.UseVisualStyleBackColor = False
        '
        'Button_Statistique_Imprime_un_rapport_Sauvegard�
        '
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard�.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard�.BackColor = System.Drawing.Color.Transparent
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard�.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard�.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue1
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard�.Location = New System.Drawing.Point(306, 106)
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard�.Name = "Button_Statistique_Imprime_un_rapport_Sauvegard�"
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard�.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard�.Size = New System.Drawing.Size(90, 30)
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard�.TabIndex = 12
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard�.Text = "Impression"
        Me.ToolTip1.SetToolTip(Me.Button_Statistique_Imprime_un_rapport_Sauvegard�, "Lancer l'impression du rapport s�lectionn� ci dessus")
        Me.Button_Statistique_Imprime_un_rapport_Sauvegard�.UseVisualStyleBackColor = False
        '
        'Button_Statistique_Effacer_la_recherche
        '
        Me.Button_Statistique_Effacer_la_recherche.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button_Statistique_Effacer_la_recherche.BackColor = System.Drawing.Color.Transparent
        Me.Button_Statistique_Effacer_la_recherche.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Statistique_Effacer_la_recherche.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue1
        Me.Button_Statistique_Effacer_la_recherche.Location = New System.Drawing.Point(214, 106)
        Me.Button_Statistique_Effacer_la_recherche.Name = "Button_Statistique_Effacer_la_recherche"
        Me.Button_Statistique_Effacer_la_recherche.Size = New System.Drawing.Size(90, 30)
        Me.Button_Statistique_Effacer_la_recherche.TabIndex = 3
        Me.Button_Statistique_Effacer_la_recherche.Text = "Effacer"
        Me.ToolTip1.SetToolTip(Me.Button_Statistique_Effacer_la_recherche, "Annule la visualisation en cours")
        Me.Button_Statistique_Effacer_la_recherche.UseVisualStyleBackColor = False
        '
        'Button_Statistique_Suppression_Rapport_Sauvegard�
        '
        Me.Button_Statistique_Suppression_Rapport_Sauvegard�.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button_Statistique_Suppression_Rapport_Sauvegard�.BackColor = System.Drawing.Color.Transparent
        Me.Button_Statistique_Suppression_Rapport_Sauvegard�.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Statistique_Suppression_Rapport_Sauvegard�.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue1
        Me.Button_Statistique_Suppression_Rapport_Sauvegard�.Location = New System.Drawing.Point(592, 106)
        Me.Button_Statistique_Suppression_Rapport_Sauvegard�.Name = "Button_Statistique_Suppression_Rapport_Sauvegard�"
        Me.Button_Statistique_Suppression_Rapport_Sauvegard�.Size = New System.Drawing.Size(95, 30)
        Me.Button_Statistique_Suppression_Rapport_Sauvegard�.TabIndex = 9
        Me.Button_Statistique_Suppression_Rapport_Sauvegard�.Text = "Suppression"
        Me.ToolTip1.SetToolTip(Me.Button_Statistique_Suppression_Rapport_Sauvegard�, "Supprime le rapport s�lectionn� ci dessus")
        Me.Button_Statistique_Suppression_Rapport_Sauvegard�.UseVisualStyleBackColor = False
        '
        'Label_Statistique_Rapports_Sauvegard�s
        '
        Me.Label_Statistique_Rapports_Sauvegard�s.AutoSize = True
        Me.Label_Statistique_Rapports_Sauvegard�s.BackColor = System.Drawing.Color.Transparent
        Me.Label_Statistique_Rapports_Sauvegard�s.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_Statistique_Rapports_Sauvegard�s.Location = New System.Drawing.Point(364, 46)
        Me.Label_Statistique_Rapports_Sauvegard�s.Name = "Label_Statistique_Rapports_Sauvegard�s"
        Me.Label_Statistique_Rapports_Sauvegard�s.Size = New System.Drawing.Size(159, 13)
        Me.Label_Statistique_Rapports_Sauvegard�s.TabIndex = 10
        Me.Label_Statistique_Rapports_Sauvegard�s.Text = "Liste des rapports Sauvegard�s "
        '
        'ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s
        '
        Me.ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s.FormattingEnabled = True
        Me.ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s.ItemHeight = 13
        Me.ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s.Location = New System.Drawing.Point(531, 43)
        Me.ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s.MaxDropDownItems = 100
        Me.ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s.Name = "ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s"
        Me.ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s.Size = New System.Drawing.Size(145, 21)
        Me.ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s.TabIndex = 7
        '
        'Button_Statistique_Ouvrir_Rapport_Sauvegard�
        '
        Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�.BackColor = System.Drawing.Color.Transparent
        Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue1
        Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�.Location = New System.Drawing.Point(499, 106)
        Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�.Name = "Button_Statistique_Ouvrir_Rapport_Sauvegard�"
        Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�.Size = New System.Drawing.Size(90, 30)
        Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�.TabIndex = 8
        Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�.Text = "Ouvrir"
        Me.ToolTip1.SetToolTip(Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�, "Affiche un rapport pr�c�demment enregistr�")
        Me.Button_Statistique_Ouvrir_Rapport_Sauvegard�.UseVisualStyleBackColor = False
        '
        'Label_Statistique_Code_Document
        '
        Me.Label_Statistique_Code_Document.AutoSize = True
        Me.Label_Statistique_Code_Document.BackColor = System.Drawing.Color.Transparent
        Me.Label_Statistique_Code_Document.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_Statistique_Code_Document.Location = New System.Drawing.Point(15, 47)
        Me.Label_Statistique_Code_Document.Name = "Label_Statistique_Code_Document"
        Me.Label_Statistique_Code_Document.Size = New System.Drawing.Size(117, 13)
        Me.Label_Statistique_Code_Document.TabIndex = 5
        Me.Label_Statistique_Code_Document.Text = "Code enregistrement (*)"
        '
        'TextBox_Statistique_CODE_SCHEMA
        '
        Me.TextBox_Statistique_CODE_SCHEMA.Location = New System.Drawing.Point(206, 46)
        Me.TextBox_Statistique_CODE_SCHEMA.Name = "TextBox_Statistique_CODE_SCHEMA"
        Me.TextBox_Statistique_CODE_SCHEMA.Size = New System.Drawing.Size(135, 20)
        Me.TextBox_Statistique_CODE_SCHEMA.TabIndex = 2
        '
        'ComboBox_Statistique_Type_recherche
        '
        Me.ComboBox_Statistique_Type_recherche.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Statistique_Type_recherche.FormattingEnabled = True
        Me.ComboBox_Statistique_Type_recherche.Items.AddRange(New Object() {""})
        Me.ComboBox_Statistique_Type_recherche.Location = New System.Drawing.Point(206, 22)
        Me.ComboBox_Statistique_Type_recherche.Name = "ComboBox_Statistique_Type_recherche"
        Me.ComboBox_Statistique_Type_recherche.Size = New System.Drawing.Size(135, 21)
        Me.ComboBox_Statistique_Type_recherche.TabIndex = 1
        '
        'Label_Statistique_Selection
        '
        Me.Label_Statistique_Selection.AutoSize = True
        Me.Label_Statistique_Selection.BackColor = System.Drawing.Color.Transparent
        Me.Label_Statistique_Selection.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_Statistique_Selection.Location = New System.Drawing.Point(15, 24)
        Me.Label_Statistique_Selection.Name = "Label_Statistique_Selection"
        Me.Label_Statistique_Selection.Size = New System.Drawing.Size(72, 13)
        Me.Label_Statistique_Selection.TabIndex = 4
        Me.Label_Statistique_Selection.Text = "S�lection       "
        '
        'Button_Statistique_Visualiser_la_recherche
        '
        Me.Button_Statistique_Visualiser_la_recherche.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button_Statistique_Visualiser_la_recherche.BackColor = System.Drawing.Color.Transparent
        Me.Button_Statistique_Visualiser_la_recherche.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Statistique_Visualiser_la_recherche.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue1
        Me.Button_Statistique_Visualiser_la_recherche.Location = New System.Drawing.Point(21, 106)
        Me.Button_Statistique_Visualiser_la_recherche.Name = "Button_Statistique_Visualiser_la_recherche"
        Me.Button_Statistique_Visualiser_la_recherche.Size = New System.Drawing.Size(90, 30)
        Me.Button_Statistique_Visualiser_la_recherche.TabIndex = 4
        Me.Button_Statistique_Visualiser_la_recherche.Text = "Visualiser"
        Me.ToolTip1.SetToolTip(Me.Button_Statistique_Visualiser_la_recherche, "Visualise les statistiques par type de document ou par Code du document")
        Me.Button_Statistique_Visualiser_la_recherche.UseVisualStyleBackColor = False
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel5.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel5.ColumnCount = 3
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 704.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.PICTURE_STAT, 1, 1)
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(-1, -1)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 3
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 55.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 341.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(958, 364)
        Me.TableLayoutPanel5.TabIndex = 13
        '
        'PICTURE_STAT
        '
        Me.PICTURE_STAT.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PICTURE_STAT.BackColor = System.Drawing.Color.Transparent
        Me.PICTURE_STAT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PICTURE_STAT.Location = New System.Drawing.Point(130, 24)
        Me.PICTURE_STAT.Name = "PICTURE_STAT"
        Me.PICTURE_STAT.Size = New System.Drawing.Size(698, 316)
        Me.PICTURE_STAT.TabIndex = 7
        Me.PICTURE_STAT.TabStop = False
        Me.PICTURE_STAT.Visible = False
        '
        'TabPage6
        '
        Me.TabPage6.BackgroundImage = CType(resources.GetObject("TabPage6.BackgroundImage"), System.Drawing.Image)
        Me.TabPage6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage6.Controls.Add(Me.TableLayoutPanel7)
        Me.TabPage6.ImageIndex = 5
        Me.TabPage6.Location = New System.Drawing.Point(4, 38)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(966, 530)
        Me.TabPage6.TabIndex = 6
        Me.TabPage6.Text = "Personnaliser"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel7
        '
        Me.TableLayoutPanel7.ColumnCount = 3
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 716.0!))
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel7.Controls.Add(Me.Personnaliser_Conteneur_Parent_GroupBox, 1, 1)
        Me.TableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel7.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel7.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel7.Name = "TableLayoutPanel7"
        Me.TableLayoutPanel7.RowCount = 3
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 488.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel7.Size = New System.Drawing.Size(964, 528)
        Me.TableLayoutPanel7.TabIndex = 3
        '
        'Personnaliser_Conteneur_Parent_GroupBox
        '
        Me.Personnaliser_Conteneur_Parent_GroupBox.BackColor = System.Drawing.Color.LightCyan
        Me.Personnaliser_Conteneur_Parent_GroupBox.Controls.Add(Me.Group_Synthese_vocale)
        Me.Personnaliser_Conteneur_Parent_GroupBox.Controls.Add(Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox)
        Me.Personnaliser_Conteneur_Parent_GroupBox.Controls.Add(Me.Personnaliser_Conteneur_Non_utilis�_GroupBox)
        Me.Personnaliser_Conteneur_Parent_GroupBox.Controls.Add(Me.Personnaliser_Couleurs_Recherches_GroupBox)
        Me.Personnaliser_Conteneur_Parent_GroupBox.Controls.Add(Me.Personnaliser_Couleurs_Texte_GroupBox)
        Me.Personnaliser_Conteneur_Parent_GroupBox.Controls.Add(Me.Personnaliser_Images__GroupBox)
        Me.Personnaliser_Conteneur_Parent_GroupBox.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Personnaliser_Conteneur_Parent_GroupBox.Location = New System.Drawing.Point(127, 23)
        Me.Personnaliser_Conteneur_Parent_GroupBox.Name = "Personnaliser_Conteneur_Parent_GroupBox"
        Me.Personnaliser_Conteneur_Parent_GroupBox.Size = New System.Drawing.Size(710, 481)
        Me.Personnaliser_Conteneur_Parent_GroupBox.TabIndex = 2
        Me.Personnaliser_Conteneur_Parent_GroupBox.TabStop = False
        '
        'Group_Synthese_vocale
        '
        Me.Group_Synthese_vocale.BackColor = System.Drawing.Color.LightCyan
        Me.Group_Synthese_vocale.Controls.Add(Me.CheckBox_Activation_synthese_vocale)
        Me.Group_Synthese_vocale.Controls.Add(Me.Parametres_synthese_vocale)
        Me.Group_Synthese_vocale.Controls.Add(Me.Parle)
        Me.Group_Synthese_vocale.DataBindings.Add(New System.Windows.Forms.Binding("ForeColor", Global.IDEALTAKE.My.MySettings.Default, "Couleur_Font", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Group_Synthese_vocale.ForeColor = Global.IDEALTAKE.My.MySettings.Default.Couleur_Font
        Me.Group_Synthese_vocale.Location = New System.Drawing.Point(12, 166)
        Me.Group_Synthese_vocale.Name = "Group_Synthese_vocale"
        Me.Group_Synthese_vocale.Size = New System.Drawing.Size(310, 95)
        Me.Group_Synthese_vocale.TabIndex = 14
        Me.Group_Synthese_vocale.TabStop = False
        Me.Group_Synthese_vocale.Text = "Synth�se Vocale"
        '
        'CheckBox_Activation_synthese_vocale
        '
        Me.CheckBox_Activation_synthese_vocale.AutoSize = True
        Me.CheckBox_Activation_synthese_vocale.Checked = Global.IDEALTAKE.My.MySettings.Default.Activation_Synthese_Vocale
        Me.CheckBox_Activation_synthese_vocale.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Global.IDEALTAKE.My.MySettings.Default, "Activation_Synthese_Vocale", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.CheckBox_Activation_synthese_vocale.Location = New System.Drawing.Point(67, 19)
        Me.CheckBox_Activation_synthese_vocale.Name = "CheckBox_Activation_synthese_vocale"
        Me.CheckBox_Activation_synthese_vocale.Size = New System.Drawing.Size(156, 17)
        Me.CheckBox_Activation_synthese_vocale.TabIndex = 28
        Me.CheckBox_Activation_synthese_vocale.Text = "Activation Synth�se Vocale"
        Me.CheckBox_Activation_synthese_vocale.UseVisualStyleBackColor = True
        '
        'Parametres_synthese_vocale
        '
        Me.Parametres_synthese_vocale.BackColor = System.Drawing.Color.Silver
        Me.Parametres_synthese_vocale.Enabled = False
        Me.Parametres_synthese_vocale.Location = New System.Drawing.Point(164, 53)
        Me.Parametres_synthese_vocale.Name = "Parametres_synthese_vocale"
        Me.Parametres_synthese_vocale.Size = New System.Drawing.Size(96, 23)
        Me.Parametres_synthese_vocale.TabIndex = 26
        Me.Parametres_synthese_vocale.Text = "Param. Synth"
        Me.Parametres_synthese_vocale.UseVisualStyleBackColor = False
        '
        'Parle
        '
        Me.Parle.BackColor = System.Drawing.Color.Silver
        Me.Parle.Enabled = False
        Me.Parle.Location = New System.Drawing.Point(40, 53)
        Me.Parle.Name = "Parle"
        Me.Parle.Size = New System.Drawing.Size(65, 23)
        Me.Parle.TabIndex = 25
        Me.Parle.Text = "Test"
        Me.Parle.UseVisualStyleBackColor = False
        '
        'Personnaliser_Utilisateurs_Gestion_Base_GroupBox
        '
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.BackColor = System.Drawing.Color.DarkTurquoise
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.Personnaliser_Utilisateurs_Action_GroupBox)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.Button28)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.Button32)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.Button31)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.Bonjour_Utilisateur)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.RadioButton2)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.RadioButton1)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.Label62)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.TextBox3)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.Label61)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.TextBox2)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.Label60)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.ListBox1)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Controls.Add(Me.Button27)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Location = New System.Drawing.Point(12, 272)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Name = "Personnaliser_Utilisateurs_Gestion_Base_GroupBox"
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Size = New System.Drawing.Size(310, 199)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.TabIndex = 0
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.TabStop = False
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.Text = "Utilisateurs de Gestion Base"
        '
        'Personnaliser_Utilisateurs_Action_GroupBox
        '
        Me.Personnaliser_Utilisateurs_Action_GroupBox.Controls.Add(Me.RadioButton28)
        Me.Personnaliser_Utilisateurs_Action_GroupBox.Controls.Add(Me.RadioButton30)
        Me.Personnaliser_Utilisateurs_Action_GroupBox.Controls.Add(Me.RadioButton29)
        Me.Personnaliser_Utilisateurs_Action_GroupBox.Location = New System.Drawing.Point(26, 27)
        Me.Personnaliser_Utilisateurs_Action_GroupBox.Name = "Personnaliser_Utilisateurs_Action_GroupBox"
        Me.Personnaliser_Utilisateurs_Action_GroupBox.Size = New System.Drawing.Size(109, 69)
        Me.Personnaliser_Utilisateurs_Action_GroupBox.TabIndex = 3
        Me.Personnaliser_Utilisateurs_Action_GroupBox.TabStop = False
        '
        'RadioButton28
        '
        Me.RadioButton28.AutoSize = True
        Me.RadioButton28.Enabled = False
        Me.RadioButton28.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RadioButton28.Location = New System.Drawing.Point(6, 10)
        Me.RadioButton28.Name = "RadioButton28"
        Me.RadioButton28.Size = New System.Drawing.Size(58, 17)
        Me.RadioButton28.TabIndex = 4
        Me.RadioButton28.TabStop = True
        Me.RadioButton28.Text = "Ajouter"
        Me.RadioButton28.UseVisualStyleBackColor = True
        '
        'RadioButton30
        '
        Me.RadioButton30.AutoSize = True
        Me.RadioButton30.Enabled = False
        Me.RadioButton30.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RadioButton30.Location = New System.Drawing.Point(6, 45)
        Me.RadioButton30.Name = "RadioButton30"
        Me.RadioButton30.Size = New System.Drawing.Size(72, 17)
        Me.RadioButton30.TabIndex = 6
        Me.RadioButton30.TabStop = True
        Me.RadioButton30.Text = "Supprimer"
        Me.RadioButton30.UseVisualStyleBackColor = True
        '
        'RadioButton29
        '
        Me.RadioButton29.AutoSize = True
        Me.RadioButton29.Enabled = False
        Me.RadioButton29.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RadioButton29.Location = New System.Drawing.Point(6, 27)
        Me.RadioButton29.Name = "RadioButton29"
        Me.RadioButton29.Size = New System.Drawing.Size(62, 17)
        Me.RadioButton29.TabIndex = 5
        Me.RadioButton29.TabStop = True
        Me.RadioButton29.Text = "Modifier"
        Me.RadioButton29.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.BackColor = System.Drawing.Color.Silver
        Me.Button28.Location = New System.Drawing.Point(244, 29)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(63, 111)
        Me.Button28.TabIndex = 13
        Me.Button28.Text = "UNIQUEMENT A RENDRE VISIBLE EN DEBUGAGE Liste des Comptes"
        Me.Button28.UseVisualStyleBackColor = False
        Me.Button28.Visible = False
        '
        'Button32
        '
        Me.Button32.BackColor = System.Drawing.Color.Silver
        Me.Button32.Enabled = False
        Me.Button32.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button32.Location = New System.Drawing.Point(112, 173)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(80, 22)
        Me.Button32.TabIndex = 12
        Me.Button32.Text = "Valider"
        Me.Button32.UseVisualStyleBackColor = False
        '
        'Button31
        '
        Me.Button31.BackColor = System.Drawing.Color.Silver
        Me.Button31.Enabled = False
        Me.Button31.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button31.Location = New System.Drawing.Point(213, 173)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(80, 22)
        Me.Button31.TabIndex = 2
        Me.Button31.Text = "Exit"
        Me.ToolTip1.SetToolTip(Me.Button31, "Cliquez pour sortir de la gestion des utilisateurs")
        Me.Button31.UseVisualStyleBackColor = False
        '
        'Bonjour_Utilisateur
        '
        Me.Bonjour_Utilisateur.AutoSize = True
        Me.Bonjour_Utilisateur.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bonjour_Utilisateur.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Bonjour_Utilisateur.Location = New System.Drawing.Point(70, 159)
        Me.Bonjour_Utilisateur.Name = "Bonjour_Utilisateur"
        Me.Bonjour_Utilisateur.Size = New System.Drawing.Size(0, 13)
        Me.Bonjour_Utilisateur.TabIndex = 12
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Enabled = False
        Me.RadioButton2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RadioButton2.Location = New System.Drawing.Point(164, 144)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(84, 17)
        Me.RadioButton2.TabIndex = 11
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Gestionnaire"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Enabled = False
        Me.RadioButton1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RadioButton1.Location = New System.Drawing.Point(67, 143)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(91, 17)
        Me.RadioButton1.TabIndex = 10
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Administrateur"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label62.Location = New System.Drawing.Point(52, 124)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(71, 13)
        Me.Label62.TabIndex = 9
        Me.Label62.Text = "Mot de passe"
        '
        'TextBox3
        '
        Me.TextBox3.Enabled = False
        Me.TextBox3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBox3.Location = New System.Drawing.Point(141, 120)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 9
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label61.Location = New System.Drawing.Point(52, 103)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(53, 13)
        Me.Label61.TabIndex = 7
        Me.Label61.Text = "Utilisateur"
        '
        'TextBox2
        '
        Me.TextBox2.Enabled = False
        Me.TextBox2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBox2.Location = New System.Drawing.Point(141, 99)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 8
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label60.Location = New System.Drawing.Point(138, 15)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(103, 13)
        Me.Label60.TabIndex = 2
        Me.Label60.Text = "Liste des Utilisateurs"
        '
        'ListBox1
        '
        Me.ListBox1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(141, 29)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(100, 69)
        Me.ListBox1.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.ListBox1, "Visible uniquement pour l'administrateur")
        '
        'Button27
        '
        Me.Button27.BackColor = System.Drawing.Color.Silver
        Me.Button27.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button27.Location = New System.Drawing.Point(6, 173)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(93, 22)
        Me.Button27.TabIndex = 1
        Me.Button27.Text = "Identifiez Vous"
        Me.Button27.UseVisualStyleBackColor = False
        '
        'Personnaliser_Conteneur_Non_utilis�_GroupBox
        '
        Me.Personnaliser_Conteneur_Non_utilis�_GroupBox.BackColor = System.Drawing.Color.LightCyan
        Me.Personnaliser_Conteneur_Non_utilis�_GroupBox.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Personnaliser_Conteneur_Non_utilis�_GroupBox.Location = New System.Drawing.Point(347, 268)
        Me.Personnaliser_Conteneur_Non_utilis�_GroupBox.Name = "Personnaliser_Conteneur_Non_utilis�_GroupBox"
        Me.Personnaliser_Conteneur_Non_utilis�_GroupBox.Size = New System.Drawing.Size(355, 203)
        Me.Personnaliser_Conteneur_Non_utilis�_GroupBox.TabIndex = 3
        Me.Personnaliser_Conteneur_Non_utilis�_GroupBox.TabStop = False
        '
        'Personnaliser_Couleurs_Recherches_GroupBox
        '
        Me.Personnaliser_Couleurs_Recherches_GroupBox.BackColor = System.Drawing.Color.LightCyan
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Controls.Add(Me.Button21)
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Controls.Add(Me.Button25)
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Controls.Add(Me.Button22)
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Controls.Add(Me.Button26)
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Controls.Add(Me.Button23)
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Controls.Add(Me.Button24)
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Controls.Add(Me.Button19)
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Controls.Add(Me.Button20)
        Me.Personnaliser_Couleurs_Recherches_GroupBox.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Location = New System.Drawing.Point(12, 67)
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Name = "Personnaliser_Couleurs_Recherches_GroupBox"
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Size = New System.Drawing.Size(310, 94)
        Me.Personnaliser_Couleurs_Recherches_GroupBox.TabIndex = 2
        Me.Personnaliser_Couleurs_Recherches_GroupBox.TabStop = False
        Me.Personnaliser_Couleurs_Recherches_GroupBox.Text = "Couleur d'arri�re-plan d'une Recherche"
        '
        'Button21
        '
        Me.Button21.BackgroundImage = Global.IDEALTAKE.My.Resources.Resources.R�initialiser_V11
        Me.Button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button21.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button21.Location = New System.Drawing.Point(263, 16)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(30, 30)
        Me.Button21.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.Button21, "Reset")
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button25
        '
        Me.Button25.BackgroundImage = Global.IDEALTAKE.My.Resources.Resources.R�initialiser_V11
        Me.Button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button25.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button25.Location = New System.Drawing.Point(263, 53)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(30, 30)
        Me.Button25.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.Button25, "Reset")
        Me.Button25.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button22.ForeColor = System.Drawing.Color.White
        Me.Button22.Location = New System.Drawing.Point(158, 16)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(88, 30)
        Me.Button22.TabIndex = 9
        Me.Button22.Text = "Avanc�e"
        Me.Button22.UseVisualStyleBackColor = False
        '
        'Button26
        '
        Me.Button26.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button26.ForeColor = System.Drawing.Color.Black
        Me.Button26.Location = New System.Drawing.Point(158, 53)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(88, 30)
        Me.Button26.TabIndex = 7
        Me.Button26.Text = "Statistique"
        Me.Button26.UseVisualStyleBackColor = False
        '
        'Button23
        '
        Me.Button23.BackgroundImage = Global.IDEALTAKE.My.Resources.Resources.R�initialiser_V11
        Me.Button23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button23.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button23.Location = New System.Drawing.Point(112, 53)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(30, 30)
        Me.Button23.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.Button23, "Reset")
        Me.Button23.UseVisualStyleBackColor = False
        '
        'Button24
        '
        Me.Button24.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(158, Byte), Integer))
        Me.Button24.ForeColor = System.Drawing.Color.Black
        Me.Button24.Location = New System.Drawing.Point(7, 53)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(88, 30)
        Me.Button24.TabIndex = 5
        Me.Button24.Text = "Guid�e"
        Me.Button24.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.BackgroundImage = Global.IDEALTAKE.My.Resources.Resources.R�initialiser_V11
        Me.Button19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button19.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button19.Location = New System.Drawing.Point(112, 16)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(30, 30)
        Me.Button19.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.Button19, "Reset")
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button20.ForeColor = System.Drawing.Color.White
        Me.Button20.Location = New System.Drawing.Point(7, 16)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(88, 30)
        Me.Button20.TabIndex = 3
        Me.Button20.Text = "Simplifi�e"
        Me.Button20.UseVisualStyleBackColor = False
        '
        'Personnaliser_Couleurs_Texte_GroupBox
        '
        Me.Personnaliser_Couleurs_Texte_GroupBox.BackColor = System.Drawing.Color.LightCyan
        Me.Personnaliser_Couleurs_Texte_GroupBox.Controls.Add(Me.Button15)
        Me.Personnaliser_Couleurs_Texte_GroupBox.Controls.Add(Me.Button14)
        Me.Personnaliser_Couleurs_Texte_GroupBox.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Personnaliser_Couleurs_Texte_GroupBox.Location = New System.Drawing.Point(12, 11)
        Me.Personnaliser_Couleurs_Texte_GroupBox.Name = "Personnaliser_Couleurs_Texte_GroupBox"
        Me.Personnaliser_Couleurs_Texte_GroupBox.Size = New System.Drawing.Size(310, 50)
        Me.Personnaliser_Couleurs_Texte_GroupBox.TabIndex = 0
        Me.Personnaliser_Couleurs_Texte_GroupBox.TabStop = False
        Me.Personnaliser_Couleurs_Texte_GroupBox.Text = "Couleur des Textes"
        '
        'Button15
        '
        Me.Button15.BackgroundImage = Global.IDEALTAKE.My.Resources.Resources.R�initialiser_V11
        Me.Button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button15.Location = New System.Drawing.Point(112, 13)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(30, 30)
        Me.Button15.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.Button15, "Reset")
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.Teal
        Me.Button14.ForeColor = System.Drawing.Color.White
        Me.Button14.Location = New System.Drawing.Point(7, 13)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(88, 30)
        Me.Button14.TabIndex = 1
        Me.Button14.Text = "Interface"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Personnaliser_Images__GroupBox
        '
        Me.Personnaliser_Images__GroupBox.BackColor = System.Drawing.Color.LightCyan
        Me.Personnaliser_Images__GroupBox.Controls.Add(Me.Button17)
        Me.Personnaliser_Images__GroupBox.Controls.Add(Me.PictureBox12)
        Me.Personnaliser_Images__GroupBox.Controls.Add(Me.PictureBox11)
        Me.Personnaliser_Images__GroupBox.Controls.Add(Me.Button18)
        Me.Personnaliser_Images__GroupBox.Controls.Add(Me.PictureBox10)
        Me.Personnaliser_Images__GroupBox.Controls.Add(Me.Button16)
        Me.Personnaliser_Images__GroupBox.Controls.Add(Me.PictureBox9)
        Me.Personnaliser_Images__GroupBox.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Personnaliser_Images__GroupBox.Location = New System.Drawing.Point(341, 11)
        Me.Personnaliser_Images__GroupBox.Name = "Personnaliser_Images__GroupBox"
        Me.Personnaliser_Images__GroupBox.Size = New System.Drawing.Size(361, 250)
        Me.Personnaliser_Images__GroupBox.TabIndex = 1
        Me.Personnaliser_Images__GroupBox.TabStop = False
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.Color.Silver
        Me.Button17.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button17.Location = New System.Drawing.Point(203, 114)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(47, 24)
        Me.Button17.TabIndex = 22
        Me.Button17.Text = "Reset"
        Me.Button17.UseVisualStyleBackColor = False
        '
        'PictureBox12
        '
        Me.PictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox12.Image = Global.IDEALTAKE.My.Resources.Resources.LOGO_V1
        Me.PictureBox12.Location = New System.Drawing.Point(92, 44)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(163, 99)
        Me.PictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox12.TabIndex = 3
        Me.PictureBox12.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox12, "Cliquez sur l'image centrale et s�lectionnez un fichier personnel , pour revenir " & _
        "� l'�cran par d�faut cliquez sur Reset")
        '
        'PictureBox11
        '
        Me.PictureBox11.Image = Global.IDEALTAKE.My.Resources.Resources.cp_haut_ecran
        Me.PictureBox11.Location = New System.Drawing.Point(6, 11)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(349, 23)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox11.TabIndex = 2
        Me.PictureBox11.TabStop = False
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.Color.Silver
        Me.Button18.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button18.Location = New System.Drawing.Point(299, 208)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(52, 24)
        Me.Button18.TabIndex = 24
        Me.Button18.Text = "Reset"
        Me.Button18.UseVisualStyleBackColor = False
        '
        'PictureBox10
        '
        Me.PictureBox10.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox10.BackgroundImage = CType(resources.GetObject("PictureBox10.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox10.Location = New System.Drawing.Point(6, 172)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(350, 73)
        Me.PictureBox10.TabIndex = 1
        Me.PictureBox10.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox10, "Cliquez sur l'image pour voir un autre fond de boite, pour revenir � l'�cran par " & _
        "d�faut cliquez sur Reset")
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.Color.Silver
        Me.Button16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button16.Location = New System.Drawing.Point(304, 137)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(47, 24)
        Me.Button16.TabIndex = 23
        Me.Button16.Text = "Reset"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox9.BackgroundImage = CType(resources.GetObject("PictureBox9.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox9.Location = New System.Drawing.Point(6, 28)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(350, 149)
        Me.PictureBox9.TabIndex = 1
        Me.PictureBox9.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox9, "Cliquez sur l'image pour voir un autre fond, pour revenir � l'�cran par d�faut cl" & _
        "iquez sur Reset")
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.Transparent
        Me.TabPage3.BackgroundImage = CType(resources.GetObject("TabPage3.BackgroundImage"), System.Drawing.Image)
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage3.Controls.Add(Me.TableLayoutPanel1)
        Me.TabPage3.ImageIndex = 6
        Me.TabPage3.Location = New System.Drawing.Point(4, 38)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(966, 530)
        Me.TabPage3.TabIndex = 3
        Me.TabPage3.Text = "Aide"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Aide_GroupBox, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Texte_Aide, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.Padding = New System.Windows.Forms.Padding(0, 0, 0, 8)
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 122.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(958, 522)
        Me.TableLayoutPanel1.TabIndex = 9
        '
        'Aide_GroupBox
        '
        Me.Aide_GroupBox.BackColor = System.Drawing.Color.DarkTurquoise
        Me.Aide_GroupBox.Controls.Add(Me.LicenceGPL)
        Me.Aide_GroupBox.Controls.Add(Me.LinkLabel1)
        Me.Aide_GroupBox.Controls.Add(Me.Diagnostique_connexion)
        Me.Aide_GroupBox.Controls.Add(Me.Utilisateur)
        Me.Aide_GroupBox.Controls.Add(Me.Label_nom_utilisateur)
        Me.Aide_GroupBox.Controls.Add(Me.Nom_de_la_base)
        Me.Aide_GroupBox.Controls.Add(Me.Label_Nom_de_la_base)
        Me.Aide_GroupBox.Controls.Add(Me.Adresse_Serveur)
        Me.Aide_GroupBox.Controls.Add(Me.Label_Adresse_Serveur)
        Me.Aide_GroupBox.Controls.Add(Me.Label_Nom_Connexion)
        Me.Aide_GroupBox.Controls.Add(Me.Nom_Connexion)
        Me.Aide_GroupBox.Controls.Add(Me.Button13)
        Me.Aide_GroupBox.Controls.Add(Me.SERVEUR_DISPONIBLE)
        Me.Aide_GroupBox.Controls.Add(Me.Label59)
        Me.Aide_GroupBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.Aide_GroupBox.Location = New System.Drawing.Point(3, 395)
        Me.Aide_GroupBox.Name = "Aide_GroupBox"
        Me.Aide_GroupBox.Size = New System.Drawing.Size(952, 115)
        Me.Aide_GroupBox.TabIndex = 8
        Me.Aide_GroupBox.TabStop = False
        '
        'LicenceGPL
        '
        Me.LicenceGPL.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.LicenceGPL.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LicenceGPL.Location = New System.Drawing.Point(30, 82)
        Me.LicenceGPL.Name = "LicenceGPL"
        Me.LicenceGPL.Size = New System.Drawing.Size(76, 23)
        Me.LicenceGPL.TabIndex = 15
        Me.LicenceGPL.Text = "Licence GPL"
        Me.LicenceGPL.UseVisualStyleBackColor = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(388, 10)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(70, 13)
        Me.LinkLabel1.TabIndex = 9
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Me contacter"
        Me.ToolTip1.SetToolTip(Me.LinkLabel1, "Besoin d'aide")
        '
        'Diagnostique_connexion
        '
        Me.Diagnostique_connexion.AutoSize = True
        Me.Diagnostique_connexion.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Diagnostique_connexion.BackColor = System.Drawing.Color.Transparent
        Me.Diagnostique_connexion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Diagnostique_connexion.DataBindings.Add(New System.Windows.Forms.Binding("ForeColor", Global.IDEALTAKE.My.MySettings.Default, "Couleur_Font", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Diagnostique_connexion.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Diagnostique_connexion.ForeColor = Global.IDEALTAKE.My.MySettings.Default.Couleur_Font
        Me.Diagnostique_connexion.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue
        Me.Diagnostique_connexion.Location = New System.Drawing.Point(391, 68)
        Me.Diagnostique_connexion.Name = "Diagnostique_connexion"
        Me.Diagnostique_connexion.Size = New System.Drawing.Size(118, 36)
        Me.Diagnostique_connexion.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.Diagnostique_connexion, "Diagnostique de la connexion")
        Me.Diagnostique_connexion.UseVisualStyleBackColor = False
        '
        'Utilisateur
        '
        Me.Utilisateur.AutoSize = True
        Me.Utilisateur.Location = New System.Drawing.Point(150, 66)
        Me.Utilisateur.Name = "Utilisateur"
        Me.Utilisateur.Size = New System.Drawing.Size(0, 13)
        Me.Utilisateur.TabIndex = 14
        '
        'Label_nom_utilisateur
        '
        Me.Label_nom_utilisateur.AutoSize = True
        Me.Label_nom_utilisateur.Location = New System.Drawing.Point(27, 66)
        Me.Label_nom_utilisateur.Name = "Label_nom_utilisateur"
        Me.Label_nom_utilisateur.Size = New System.Drawing.Size(84, 13)
        Me.Label_nom_utilisateur.TabIndex = 13
        Me.Label_nom_utilisateur.Text = "Nom d'utilisateur"
        '
        'Nom_de_la_base
        '
        Me.Nom_de_la_base.AutoSize = True
        Me.Nom_de_la_base.Location = New System.Drawing.Point(150, 50)
        Me.Nom_de_la_base.Name = "Nom_de_la_base"
        Me.Nom_de_la_base.Size = New System.Drawing.Size(0, 13)
        Me.Nom_de_la_base.TabIndex = 12
        '
        'Label_Nom_de_la_base
        '
        Me.Label_Nom_de_la_base.AutoSize = True
        Me.Label_Nom_de_la_base.Location = New System.Drawing.Point(27, 50)
        Me.Label_Nom_de_la_base.Name = "Label_Nom_de_la_base"
        Me.Label_Nom_de_la_base.Size = New System.Drawing.Size(81, 13)
        Me.Label_Nom_de_la_base.TabIndex = 11
        Me.Label_Nom_de_la_base.Text = "Nom de la base"
        '
        'Adresse_Serveur
        '
        Me.Adresse_Serveur.AutoSize = True
        Me.Adresse_Serveur.Location = New System.Drawing.Point(150, 34)
        Me.Adresse_Serveur.Name = "Adresse_Serveur"
        Me.Adresse_Serveur.Size = New System.Drawing.Size(0, 13)
        Me.Adresse_Serveur.TabIndex = 10
        '
        'Label_Adresse_Serveur
        '
        Me.Label_Adresse_Serveur.AutoSize = True
        Me.Label_Adresse_Serveur.Location = New System.Drawing.Point(27, 34)
        Me.Label_Adresse_Serveur.Name = "Label_Adresse_Serveur"
        Me.Label_Adresse_Serveur.Size = New System.Drawing.Size(85, 13)
        Me.Label_Adresse_Serveur.TabIndex = 9
        Me.Label_Adresse_Serveur.Text = "Adresse Serveur"
        '
        'Label_Nom_Connexion
        '
        Me.Label_Nom_Connexion.AutoSize = True
        Me.Label_Nom_Connexion.Location = New System.Drawing.Point(27, 20)
        Me.Label_Nom_Connexion.Name = "Label_Nom_Connexion"
        Me.Label_Nom_Connexion.Size = New System.Drawing.Size(108, 13)
        Me.Label_Nom_Connexion.TabIndex = 8
        Me.Label_Nom_Connexion.Text = "Nom de la Connexion"
        '
        'Nom_Connexion
        '
        Me.Nom_Connexion.AutoSize = True
        Me.Nom_Connexion.Location = New System.Drawing.Point(150, 20)
        Me.Nom_Connexion.Name = "Nom_Connexion"
        Me.Nom_Connexion.Size = New System.Drawing.Size(0, 13)
        Me.Nom_Connexion.TabIndex = 7
        '
        'Button13
        '
        Me.Button13.AccessibleDescription = ""
        Me.Button13.AutoSize = True
        Me.Button13.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button13.BackColor = System.Drawing.Color.Transparent
        Me.Button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button13.DataBindings.Add(New System.Windows.Forms.Binding("ForeColor", Global.IDEALTAKE.My.MySettings.Default, "Couleur_Font", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Button13.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.ForeColor = Global.IDEALTAKE.My.MySettings.Default.Couleur_Font
        Me.Button13.Image = Global.IDEALTAKE.My.Resources.Resources.bouton_nue1
        Me.Button13.Location = New System.Drawing.Point(516, 68)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(118, 36)
        Me.Button13.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.Button13, "Ce bouton rafraichit l'indication d'�tat du serveur.")
        Me.Button13.UseVisualStyleBackColor = False
        '
        'SERVEUR_DISPONIBLE
        '
        Me.SERVEUR_DISPONIBLE.AutoSize = True
        Me.SERVEUR_DISPONIBLE.BackColor = System.Drawing.Color.White
        Me.SERVEUR_DISPONIBLE.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SERVEUR_DISPONIBLE.ForeColor = System.Drawing.Color.Red
        Me.SERVEUR_DISPONIBLE.Location = New System.Drawing.Point(518, 26)
        Me.SERVEUR_DISPONIBLE.Name = "SERVEUR_DISPONIBLE"
        Me.SERVEUR_DISPONIBLE.Size = New System.Drawing.Size(0, 13)
        Me.SERVEUR_DISPONIBLE.TabIndex = 5
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(388, 26)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(124, 13)
        Me.Label59.TabIndex = 4
        Me.Label59.Text = "Etat Serveur MySql :"
        '
        'Texte_Aide
        '
        Me.Texte_Aide.BackColor = System.Drawing.Color.LightCyan
        Me.Texte_Aide.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Texte_Aide.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Texte_Aide.Location = New System.Drawing.Point(3, 3)
        Me.Texte_Aide.Multiline = True
        Me.Texte_Aide.Name = "Texte_Aide"
        Me.Texte_Aide.ReadOnly = True
        Me.Texte_Aide.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Texte_Aide.Size = New System.Drawing.Size(952, 386)
        Me.Texte_Aide.TabIndex = 0
        Me.Texte_Aide.Text = resources.GetString("Texte_Aide.Text")
        '
        'ImageList_TabControl1
        '
        Me.ImageList_TabControl1.ImageStream = CType(resources.GetObject("ImageList_TabControl1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList_TabControl1.TransparentColor = System.Drawing.Color.White
        Me.ImageList_TabControl1.Images.SetKeyName(0, "Gestion_base_8bits_47x34v3.bmp")
        Me.ImageList_TabControl1.Images.SetKeyName(1, "Recherche_Simplifi�e_8bits_47x34_v4.bmp")
        Me.ImageList_TabControl1.Images.SetKeyName(2, "Recherche_Avanc�e_8bits_47x34_v7.bmp")
        Me.ImageList_TabControl1.Images.SetKeyName(3, "Recherche_Guid�e_8bits_47x34_v4.bmp")
        Me.ImageList_TabControl1.Images.SetKeyName(4, "Statistiques_8bits_38x30_v7.bmp")
        Me.ImageList_TabControl1.Images.SetKeyName(5, "Personnaliser_8bits_47x34_v5.bmp")
        Me.ImageList_TabControl1.Images.SetKeyName(6, "Aide_8bits_47x34_v2.bmp")
        Me.ImageList_TabControl1.Images.SetKeyName(7, "Fl�che_verte_pointant_vers_le_bas_8bits_11x13_v5.bmp")
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem13, Me.ToolStripMenuItem14, Me.ToolStripMenuItem15, Me.ToolStripMenuItem16, Me.ToolStripMenuItem17, Me.ToolStripMenuItem18, Me.ToolStripMenuItem19, Me.ToolStripMenuItem20, Me.ToolStripMenuItem21, Me.ToolStripMenuItem22, Me.ToolStripMenuItem23, Me.ToolStripMenuItem24, Me.ToolStripMenuItem25, Me.ToolStripMenuItem26, Me.ToolStripMenuItem27, Me.ToolStripMenuItem28, Me.ToolStripMenuItem29, Me.ToolStripMenuItem30, Me.ToolStripMenuItem31, Me.ToolStripMenuItem32, Me.ToolStripMenuItem33, Me.ToolStripMenuItem34, Me.ToolStripMenuItem35, Me.ToolStripMenuItem36, Me.ToolStripMenuItem37, Me.ToolStripMenuItem38})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(209, 576)
        '
        'ToolStripMenuItem13
        '
        Me.ToolStripMenuItem13.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackColor_ToolStripComboBox})
        Me.ToolStripMenuItem13.Name = "ToolStripMenuItem13"
        Me.ToolStripMenuItem13.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem13.Text = "BackColor"
        '
        'BackColor_ToolStripComboBox
        '
        Me.BackColor_ToolStripComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.BackColor_ToolStripComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.BackColor_ToolStripComboBox.Items.AddRange(New Object() {"None", "AliceBlue", "AntiqueWhite", "Aqua", "Aquamarine", "Azure", "Beige", "Bisque", "Black", "BlanchedAlmond", "Blue", "BlueViolet", "Brown", "BurlyWood", "CadetBlue", "Chartreuse", "Chocolate", "Control", "ControlText", "Coral", "CornflowerBlue", "Cornsilk", "Crimson ", "Cyan", "DarkBlue ", "DarkCyan ", "DarkGoldenRod", "DarkGray ", "DarkGreen", "DarkKhaki ", "DarkMagenta ", "DarkOliveGreen", "Darkorange", "DarkOrchid", "DarkRed", "DarkSalmon", "DarkSeaGreen ", "DarkSlateBlue ", "DarkSlateGray", "DarkTurquoise", "DarkViolet", "DeepPink", "DeepSkyBlue ", "DimGray", "DodgerBlue ", "FireBrick ", "FloralWhite", "ForestGreen", "Fuchsia ", "Gainsboro", "GhostWhite", "Gold", "GoldenRod", "Gray", "Green", "GreenYellow", "HoneyDew", "HotPink", "IndianRed", "Indigo", "Ivory", "Khaki", "Lavender", "LavenderBlush", "LawnGreen", "LemonChiffon", "LightBlue", "LightCoral", "LightCyan", "LightGoldenRodYellow", "LightGrey", "LightGreen", "LightPink", "LightSalmon", "LightSeaGreen", "LightSkyBlue", "LightSlateGray", "LightSteelBlue", "LightYellow", "Lime", "LimeGreen", "Linen", "Magenta", "Maroon ", "MediumAquaMarine", "MediumBlue", "MediumOrchid", "MediumPurple", "MediumSeaGreen", "MediumSlateBlue", "MediumSpringGreen", "MediumTurquoise", "MediumVioletRed", "MidnightBlue", "MintCream", "MistyRose", "Moccasin", "NavajoWhite ", "Navy", "OldLace", "Olive", "OliveDrab", "Orange", "OrangeRed", "Orchid", "PaleGoldenRod", "PaleGreen", "PaleTurquoise", "PaleVioletRed", "PapayaWhip", "PeachPuff", "Peru", "Pink", "Plum", "PowderBlue", "Purple", "Red", "RosyBrown", "RoyalBlue", "SaddleBrown", "Salmon", "SandyBrown", "SeaGreen", "SeaShell", "Sienna", "Silver", "SkyBlue", "SlateBlue", "SlateGray", "Snow", "SpringGreen", "SteelBlue", "Tan", "Teal", "Thistle", "Tomato", "Transparent", "Turquoise", "Violet", "Wheat", "White", "WhiteSmoke", "Yellow", "YellowGreen"})
        Me.BackColor_ToolStripComboBox.Name = "BackColor_ToolStripComboBox"
        Me.BackColor_ToolStripComboBox.Size = New System.Drawing.Size(180, 21)
        '
        'ToolStripMenuItem14
        '
        Me.ToolStripMenuItem14.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackGroungImage_ToolStripTextBox})
        Me.ToolStripMenuItem14.Name = "ToolStripMenuItem14"
        Me.ToolStripMenuItem14.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem14.Text = "Background_image"
        '
        'BackGroungImage_ToolStripTextBox
        '
        Me.BackGroungImage_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.BackGroungImage_ToolStripTextBox.Name = "BackGroungImage_ToolStripTextBox"
        Me.BackGroungImage_ToolStripTextBox.Size = New System.Drawing.Size(250, 21)
        '
        'ToolStripMenuItem15
        '
        Me.ToolStripMenuItem15.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackGroungImageLayout_ToolStripComboBox})
        Me.ToolStripMenuItem15.Name = "ToolStripMenuItem15"
        Me.ToolStripMenuItem15.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem15.Text = "BackGroungImageLayout"
        '
        'BackGroungImageLayout_ToolStripComboBox
        '
        Me.BackGroungImageLayout_ToolStripComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.BackGroungImageLayout_ToolStripComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.BackGroungImageLayout_ToolStripComboBox.Items.AddRange(New Object() {"None", "ImageLayout.None", "ImageLayout.Tile", "ImageLayout.Center", "ImageLayout.Stretch", "ImageLayout.Zoom"})
        Me.BackGroungImageLayout_ToolStripComboBox.Name = "BackGroungImageLayout_ToolStripComboBox"
        Me.BackGroungImageLayout_ToolStripComboBox.Size = New System.Drawing.Size(121, 21)
        '
        'ToolStripMenuItem16
        '
        Me.ToolStripMenuItem16.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Cursor_ToolStripComboBox})
        Me.ToolStripMenuItem16.Name = "ToolStripMenuItem16"
        Me.ToolStripMenuItem16.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem16.Text = "Cursor"
        '
        'Cursor_ToolStripComboBox
        '
        Me.Cursor_ToolStripComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cursor_ToolStripComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Cursor_ToolStripComboBox.Items.AddRange(New Object() {"None", "AppStarting", "Arrow", "Cross", "Default", "Hand", "Help", "HSplit", "IBeam", "No", "NoMove2D", "NoMoveHoriz", "NoMoveVert", "PanEast", "PanNE", "PanNorth", "PanNW", "PanSE", "PanSouth", "PanSW", "PanWest", "SizeAll", "SizeNESW", "SizeNS", "SizeNWSE", "SizeWE", "UpArrow", "VSplit", "WaitCursor"})
        Me.Cursor_ToolStripComboBox.Name = "Cursor_ToolStripComboBox"
        Me.Cursor_ToolStripComboBox.Size = New System.Drawing.Size(121, 21)
        '
        'ToolStripMenuItem17
        '
        Me.ToolStripMenuItem17.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Font_ToolStripTextBox})
        Me.ToolStripMenuItem17.Name = "ToolStripMenuItem17"
        Me.ToolStripMenuItem17.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem17.Text = "Font"
        '
        'Font_ToolStripTextBox
        '
        Me.Font_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Font_ToolStripTextBox.Name = "Font_ToolStripTextBox"
        Me.Font_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem18
        '
        Me.ToolStripMenuItem18.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ForeColor_ToolStripComboBox})
        Me.ToolStripMenuItem18.Name = "ToolStripMenuItem18"
        Me.ToolStripMenuItem18.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem18.Text = "ForeColor"
        '
        'ForeColor_ToolStripComboBox
        '
        Me.ForeColor_ToolStripComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ForeColor_ToolStripComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.ForeColor_ToolStripComboBox.Items.AddRange(New Object() {"None", "AliceBlue", "AntiqueWhite", "Aqua", "Aquamarine", "Azure", "Beige", "Bisque", "Black", "BlanchedAlmond", "Blue", "BlueViolet", "Brown", "BurlyWood", "CadetBlue", "Chartreuse", "Chocolate", "Control", "ControlText", "Coral", "CornflowerBlue", "Cornsilk", "Crimson ", "Cyan", "DarkBlue ", "DarkCyan ", "DarkGoldenRod", "DarkGray ", "DarkGreen", "DarkKhaki ", "DarkMagenta ", "DarkOliveGreen", "Darkorange", "DarkOrchid", "DarkRed", "DarkSalmon", "DarkSeaGreen ", "DarkSlateBlue ", "DarkSlateGray", "DarkTurquoise", "DarkViolet", "DeepPink", "DeepSkyBlue ", "DimGray", "DodgerBlue ", "FireBrick ", "FloralWhite", "ForestGreen", "Fuchsia ", "Gainsboro", "GhostWhite", "Gold", "GoldenRod", "Gray", "Green", "GreenYellow", "HoneyDew", "HotPink", "IndianRed", "Indigo", "Ivory", "Khaki", "Lavender", "LavenderBlush", "LawnGreen", "LemonChiffon", "LightBlue", "LightCoral", "LightCyan", "LightGoldenRodYellow", "LightGrey", "LightGreen", "LightPink", "LightSalmon", "LightSeaGreen", "LightSkyBlue", "LightSlateGray", "LightSteelBlue", "LightYellow", "Lime", "LimeGreen", "Linen", "Magenta", "Maroon ", "MediumAquaMarine", "MediumBlue", "MediumOrchid", "MediumPurple", "MediumSeaGreen", "MediumSlateBlue", "MediumSpringGreen", "MediumTurquoise", "MediumVioletRed", "MidnightBlue", "MintCream", "MistyRose", "Moccasin", "NavajoWhite ", "Navy", "OldLace", "Olive", "OliveDrab", "Orange", "OrangeRed", "Orchid", "PaleGoldenRod", "PaleGreen", "PaleTurquoise", "PaleVioletRed", "PapayaWhip", "PeachPuff", "Peru", "Pink", "Plum", "PowderBlue", "Purple", "Red", "RosyBrown", "RoyalBlue", "SaddleBrown", "Salmon", "SandyBrown", "SeaGreen", "SeaShell", "Sienna", "Silver", "SkyBlue", "SlateBlue", "SlateGray", "Snow", "SpringGreen", "SteelBlue", "Tan", "Teal", "Thistle", "Tomato", "Transparent", "Turquoise", "Violet", "Wheat", "White", "WhiteSmoke", "Yellow", "YellowGreen"})
        Me.ForeColor_ToolStripComboBox.Name = "ForeColor_ToolStripComboBox"
        Me.ForeColor_ToolStripComboBox.Size = New System.Drawing.Size(180, 21)
        '
        'ToolStripMenuItem19
        '
        Me.ToolStripMenuItem19.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.hauteur_ToolStripTextBox})
        Me.ToolStripMenuItem19.Name = "ToolStripMenuItem19"
        Me.ToolStripMenuItem19.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem19.Text = "hauteur"
        '
        'hauteur_ToolStripTextBox
        '
        Me.hauteur_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.hauteur_ToolStripTextBox.Name = "hauteur_ToolStripTextBox"
        Me.hauteur_ToolStripTextBox.Size = New System.Drawing.Size(100, 21)
        '
        'ToolStripMenuItem20
        '
        Me.ToolStripMenuItem20.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Items_Allemand_ToolStripTextBox})
        Me.ToolStripMenuItem20.Name = "ToolStripMenuItem20"
        Me.ToolStripMenuItem20.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem20.Text = "Items_Allemand"
        '
        'Items_Allemand_ToolStripTextBox
        '
        Me.Items_Allemand_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Items_Allemand_ToolStripTextBox.Name = "Items_Allemand_ToolStripTextBox"
        Me.Items_Allemand_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem21
        '
        Me.ToolStripMenuItem21.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Items_Anglais_ToolStripTextBox})
        Me.ToolStripMenuItem21.Name = "ToolStripMenuItem21"
        Me.ToolStripMenuItem21.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem21.Text = "Items_Anglais"
        '
        'Items_Anglais_ToolStripTextBox
        '
        Me.Items_Anglais_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Items_Anglais_ToolStripTextBox.Name = "Items_Anglais_ToolStripTextBox"
        Me.Items_Anglais_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem22
        '
        Me.ToolStripMenuItem22.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Items_Espagnole_ToolStripTextBox})
        Me.ToolStripMenuItem22.Name = "ToolStripMenuItem22"
        Me.ToolStripMenuItem22.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem22.Text = "Items_Espagnole"
        '
        'Items_Espagnole_ToolStripTextBox
        '
        Me.Items_Espagnole_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Items_Espagnole_ToolStripTextBox.Name = "Items_Espagnole_ToolStripTextBox"
        Me.Items_Espagnole_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem23
        '
        Me.ToolStripMenuItem23.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Items_Francais_ToolStripTextBox})
        Me.ToolStripMenuItem23.Name = "ToolStripMenuItem23"
        Me.ToolStripMenuItem23.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem23.Text = "Items_Francais"
        '
        'Items_Francais_ToolStripTextBox
        '
        Me.Items_Francais_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Items_Francais_ToolStripTextBox.Name = "Items_Francais_ToolStripTextBox"
        Me.Items_Francais_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem24
        '
        Me.ToolStripMenuItem24.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Items_Italien_ToolStripTextBox})
        Me.ToolStripMenuItem24.Name = "ToolStripMenuItem24"
        Me.ToolStripMenuItem24.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem24.Text = "Items_Italien"
        '
        'Items_Italien_ToolStripTextBox
        '
        Me.Items_Italien_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Items_Italien_ToolStripTextBox.Name = "Items_Italien_ToolStripTextBox"
        Me.Items_Italien_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem25
        '
        Me.ToolStripMenuItem25.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.largeur_ToolStripTextBox})
        Me.ToolStripMenuItem25.Name = "ToolStripMenuItem25"
        Me.ToolStripMenuItem25.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem25.Text = "largeur"
        '
        'largeur_ToolStripTextBox
        '
        Me.largeur_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.largeur_ToolStripTextBox.Name = "largeur_ToolStripTextBox"
        Me.largeur_ToolStripTextBox.Size = New System.Drawing.Size(100, 21)
        '
        'ToolStripMenuItem26
        '
        Me.ToolStripMenuItem26.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Position_X_ToolStripTextBox})
        Me.ToolStripMenuItem26.Name = "ToolStripMenuItem26"
        Me.ToolStripMenuItem26.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem26.Text = "Position_X"
        '
        'Position_X_ToolStripTextBox
        '
        Me.Position_X_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Position_X_ToolStripTextBox.Name = "Position_X_ToolStripTextBox"
        Me.Position_X_ToolStripTextBox.Size = New System.Drawing.Size(100, 21)
        '
        'ToolStripMenuItem27
        '
        Me.ToolStripMenuItem27.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Position_Y_ToolStripTextBox})
        Me.ToolStripMenuItem27.Name = "ToolStripMenuItem27"
        Me.ToolStripMenuItem27.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem27.Text = "Position_Y"
        '
        'Position_Y_ToolStripTextBox
        '
        Me.Position_Y_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Position_Y_ToolStripTextBox.Name = "Position_Y_ToolStripTextBox"
        Me.Position_Y_ToolStripTextBox.Size = New System.Drawing.Size(100, 21)
        '
        'ToolStripMenuItem28
        '
        Me.ToolStripMenuItem28.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TabIndex_ToolStripTextBox})
        Me.ToolStripMenuItem28.Name = "ToolStripMenuItem28"
        Me.ToolStripMenuItem28.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem28.Text = "TabIndex"
        '
        'TabIndex_ToolStripTextBox
        '
        Me.TabIndex_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.TabIndex_ToolStripTextBox.Name = "TabIndex_ToolStripTextBox"
        Me.TabIndex_ToolStripTextBox.Size = New System.Drawing.Size(100, 21)
        '
        'ToolStripMenuItem29
        '
        Me.ToolStripMenuItem29.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Text_Allemand_ToolStripTextBox})
        Me.ToolStripMenuItem29.Name = "ToolStripMenuItem29"
        Me.ToolStripMenuItem29.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem29.Text = "Text_Allemand"
        '
        'Text_Allemand_ToolStripTextBox
        '
        Me.Text_Allemand_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Text_Allemand_ToolStripTextBox.Name = "Text_Allemand_ToolStripTextBox"
        Me.Text_Allemand_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem30
        '
        Me.ToolStripMenuItem30.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Text_Anglais_ToolStripTextBox})
        Me.ToolStripMenuItem30.Name = "ToolStripMenuItem30"
        Me.ToolStripMenuItem30.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem30.Text = "Text_Anglais"
        '
        'Text_Anglais_ToolStripTextBox
        '
        Me.Text_Anglais_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Text_Anglais_ToolStripTextBox.Name = "Text_Anglais_ToolStripTextBox"
        Me.Text_Anglais_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem31
        '
        Me.ToolStripMenuItem31.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Text_Espagnole_ToolStripTextBox})
        Me.ToolStripMenuItem31.Name = "ToolStripMenuItem31"
        Me.ToolStripMenuItem31.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem31.Text = "Text_Espagnole"
        '
        'Text_Espagnole_ToolStripTextBox
        '
        Me.Text_Espagnole_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Text_Espagnole_ToolStripTextBox.Name = "Text_Espagnole_ToolStripTextBox"
        Me.Text_Espagnole_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem32
        '
        Me.ToolStripMenuItem32.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Text_Francais_ToolStripTextBox})
        Me.ToolStripMenuItem32.Name = "ToolStripMenuItem32"
        Me.ToolStripMenuItem32.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem32.Text = "Text_Francais"
        '
        'Text_Francais_ToolStripTextBox
        '
        Me.Text_Francais_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Text_Francais_ToolStripTextBox.Name = "Text_Francais_ToolStripTextBox"
        Me.Text_Francais_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem33
        '
        Me.ToolStripMenuItem33.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Text_Italien_ToolStripTextBox})
        Me.ToolStripMenuItem33.Name = "ToolStripMenuItem33"
        Me.ToolStripMenuItem33.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem33.Text = "Text_Italien"
        '
        'Text_Italien_ToolStripTextBox
        '
        Me.Text_Italien_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Text_Italien_ToolStripTextBox.Name = "Text_Italien_ToolStripTextBox"
        Me.Text_Italien_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem34
        '
        Me.ToolStripMenuItem34.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolTip_Allemand_ToolStripTextBox})
        Me.ToolStripMenuItem34.Name = "ToolStripMenuItem34"
        Me.ToolStripMenuItem34.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem34.Text = "ToolTip_Allemand"
        '
        'ToolTip_Allemand_ToolStripTextBox
        '
        Me.ToolTip_Allemand_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.ToolTip_Allemand_ToolStripTextBox.Name = "ToolTip_Allemand_ToolStripTextBox"
        Me.ToolTip_Allemand_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem35
        '
        Me.ToolStripMenuItem35.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolTip_Anglais_ToolStripTextBox})
        Me.ToolStripMenuItem35.Name = "ToolStripMenuItem35"
        Me.ToolStripMenuItem35.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem35.Text = "ToolTip_Anglais"
        '
        'ToolTip_Anglais_ToolStripTextBox
        '
        Me.ToolTip_Anglais_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.ToolTip_Anglais_ToolStripTextBox.Name = "ToolTip_Anglais_ToolStripTextBox"
        Me.ToolTip_Anglais_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem36
        '
        Me.ToolStripMenuItem36.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolTip_Espagnole_ToolStripTextBox})
        Me.ToolStripMenuItem36.Name = "ToolStripMenuItem36"
        Me.ToolStripMenuItem36.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem36.Text = "ToolTip_Espagnole"
        '
        'ToolTip_Espagnole_ToolStripTextBox
        '
        Me.ToolTip_Espagnole_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.ToolTip_Espagnole_ToolStripTextBox.Name = "ToolTip_Espagnole_ToolStripTextBox"
        Me.ToolTip_Espagnole_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem37
        '
        Me.ToolStripMenuItem37.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolTip_Francais_ToolStripTextBox})
        Me.ToolStripMenuItem37.Name = "ToolStripMenuItem37"
        Me.ToolStripMenuItem37.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem37.Text = "ToolTip_Francais"
        '
        'ToolTip_Francais_ToolStripTextBox
        '
        Me.ToolTip_Francais_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.ToolTip_Francais_ToolStripTextBox.Name = "ToolTip_Francais_ToolStripTextBox"
        Me.ToolTip_Francais_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'ToolStripMenuItem38
        '
        Me.ToolStripMenuItem38.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolTip_Italien_ToolStripTextBox})
        Me.ToolStripMenuItem38.Name = "ToolStripMenuItem38"
        Me.ToolStripMenuItem38.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem38.Text = "ToolTip_Italien"
        '
        'ToolTip_Italien_ToolStripTextBox
        '
        Me.ToolTip_Italien_ToolStripTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.ToolTip_Italien_ToolStripTextBox.Name = "ToolTip_Italien_ToolStripTextBox"
        Me.ToolTip_Italien_ToolStripTextBox.Size = New System.Drawing.Size(300, 21)
        '
        'PrintDialog1
        '
        Me.PrintDialog1.UseEXDialog = True
        '
        'Timer1EtatServeur
        '
        Me.Timer1EtatServeur.Enabled = True
        Me.Timer1EtatServeur.Interval = 25000
        '
        'Timer2EtatServeur
        '
        Me.Timer2EtatServeur.Enabled = True
        Me.Timer2EtatServeur.Interval = 3000
        '
        'ZoomToolStripMenuItem2
        '
        Me.ZoomToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ZoomPlusToolStripMenuItem3, Me.ZoomMoinToolStripMenuItem4, Me.ResetZoomToolStripMenuItem1})
        Me.ZoomToolStripMenuItem2.Name = "ZoomToolStripMenuItem2"
        Me.ZoomToolStripMenuItem2.Size = New System.Drawing.Size(91, 20)
        Me.ZoomToolStripMenuItem2.Text = "Zoom 100%"
        '
        'ZoomPlusToolStripMenuItem3
        '
        Me.ZoomPlusToolStripMenuItem3.Name = "ZoomPlusToolStripMenuItem3"
        Me.ZoomPlusToolStripMenuItem3.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.ZoomPlusToolStripMenuItem3.Size = New System.Drawing.Size(183, 22)
        Me.ZoomPlusToolStripMenuItem3.Text = "Zoom +"
        '
        'ZoomMoinToolStripMenuItem4
        '
        Me.ZoomMoinToolStripMenuItem4.Name = "ZoomMoinToolStripMenuItem4"
        Me.ZoomMoinToolStripMenuItem4.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.ZoomMoinToolStripMenuItem4.Size = New System.Drawing.Size(183, 22)
        Me.ZoomMoinToolStripMenuItem4.Text = "Zoom -"
        '
        'ResetZoomToolStripMenuItem1
        '
        Me.ResetZoomToolStripMenuItem1.Name = "ResetZoomToolStripMenuItem1"
        Me.ResetZoomToolStripMenuItem1.Size = New System.Drawing.Size(183, 22)
        Me.ResetZoomToolStripMenuItem1.Text = "Reset Zoom"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.ToolStripMenuItem3, Me.ToolStripMenuItem4})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(91, 20)
        Me.ToolStripMenuItem1.Text = "Zoom 100%"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(178, 22)
        Me.ToolStripMenuItem2.Text = "Zoom +"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Alt) _
            Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(178, 22)
        Me.ToolStripMenuItem3.Text = "Zoom -"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(178, 22)
        Me.ToolStripMenuItem4.Text = "Reset Zoom"
        '
        'T�che_de_fond
        '
        Me.T�che_de_fond.WorkerSupportsCancellation = True
        '
        'Timer_Verification_excution_SAPI5
        '
        Me.Timer_Verification_excution_SAPI5.Enabled = True
        Me.Timer_Verification_excution_SAPI5.Interval = 5000
        '
        'T�che_de_fond_SAPI
        '
        Me.T�che_de_fond_SAPI.WorkerSupportsCancellation = True
        '
        'T�che_de_fond_RS_MOTS_CLEFS
        '
        Me.T�che_de_fond_RS_MOTS_CLEFS.WorkerSupportsCancellation = True
        '
        'BackgroundWorker_RS
        '
        Me.BackgroundWorker_RS.WorkerReportsProgress = True
        Me.BackgroundWorker_RS.WorkerSupportsCancellation = True
        '
        'BackgroundWorker_RA
        '
        Me.BackgroundWorker_RA.WorkerReportsProgress = True
        Me.BackgroundWorker_RA.WorkerSupportsCancellation = True
        '
        'BackgroundWorker_RG
        '
        Me.BackgroundWorker_RG.WorkerReportsProgress = True
        Me.BackgroundWorker_RG.WorkerSupportsCancellation = True
        '
        'Timer3AutocompleteRsMotsClefs
        '
        Me.Timer3AutocompleteRsMotsClefs.Enabled = True
        Me.Timer3AutocompleteRsMotsClefs.Interval = 1000
        '
        'TimerEtatRA
        '
        Me.TimerEtatRA.Interval = 1000
        '
        'TimerEtatRG
        '
        Me.TimerEtatRG.Interval = 1000
        '
        'BackgroundWorker_Diagnostic
        '
        Me.BackgroundWorker_Diagnostic.WorkerReportsProgress = True
        Me.BackgroundWorker_Diagnostic.WorkerSupportsCancellation = True
        '
        'TimerEtatDiagnostic
        '
        Me.TimerEtatDiagnostic.Interval = 1000
        '
        'TimerEtatDetailsEnregistrementW1
        '
        Me.TimerEtatDetailsEnregistrementW1.Interval = 1000
        '
        'BackgroundWorkerDetailsEnregistrementW1
        '
        '
        'TimerEtatDetailsEnregistrementW2
        '
        Me.TimerEtatDetailsEnregistrementW2.Interval = 1000
        '
        'TimerEtatDetailsEnregistrementW3
        '
        Me.TimerEtatDetailsEnregistrementW3.Interval = 1000
        '
        'BackgroundWorkerDetailsEnregistrementW2
        '
        '
        'BackgroundWorkerDetailsEnregistrementW3
        '
        '
        'TimerEtatRechercheGestionBase
        '
        Me.TimerEtatRechercheGestionBase.Interval = 1000
        '
        'BackgroundWorkerRechercheGestionBase
        '
        '
        'BackgroundWorkerAjoutCompteGestionBase
        '
        '
        'TimerEtatAjoutCompteGestionBase
        '
        Me.TimerEtatAjoutCompteGestionBase.Interval = 1000
        '
        'BackgroundWorkerAuthentificationtCompteGestionBase
        '
        '
        'TimerEtatAuthentificationtCompteGestionBase
        '
        Me.TimerEtatAuthentificationtCompteGestionBase.Interval = 1000
        '
        'BackgroundWorkerR�cup�rationCompteGestionBase
        '
        '
        'TimerEtatR�cup�rationCompteGestionBase
        '
        Me.TimerEtatR�cup�rationCompteGestionBase.Interval = 1000
        '
        'BackgroundWorkerSupprimerCompteGestionBase
        '
        '
        'TimerEtatSupprimerCompteGestionBase
        '
        Me.TimerEtatSupprimerCompteGestionBase.Interval = 1000
        '
        'BackgroundWorkerSupprimeEnregistrement
        '
        '
        'TimerSupprimeEnregistrement
        '
        Me.TimerSupprimeEnregistrement.Interval = 1000
        '
        'BackgroundWorkerAjoutEnregistrement
        '
        '
        'TimerEtatAjoutEnregistrement
        '
        Me.TimerEtatAjoutEnregistrement.Interval = 1000
        '
        'TimerEtatAjoutTreeviewPosition
        '
        Me.TimerEtatAjoutTreeviewPosition.Interval = 1000
        '
        'BackgroundWorkerAjoutTreeviewPosition
        '
        '
        'BackgroundWorkerAjoutLiensR�f�rences
        '
        '
        'TimerEtatAjoutLiensR�f�rences
        '
        Me.TimerEtatAjoutLiensR�f�rences.Interval = 1000
        '
        'BackgroundWorkerSupprimeLiensR�f�rences
        '
        '
        'TimerEtatSupprimeLiensR�f�rences
        '
        Me.TimerEtatSupprimeLiensR�f�rences.Interval = 1000
        '
        'BackgroundWorkerTransfert
        '
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'BackgroundWorkerChargementEnregistrement
        '
        '
        'TimerChargementEnregistrement
        '
        Me.TimerChargementEnregistrement.Interval = 1000
        '
        'BackgroundWorkerMise�JourEnregistrement
        '
        '
        'TimerMise�JourEnregistrement
        '
        Me.TimerMise�JourEnregistrement.Interval = 1000
        '
        'BackgroundWorkerMiniVLCPlayer
        '
        '
        'Form_Demarrage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.ClientSize = New System.Drawing.Size(974, 572)
        Me.Controls.Add(Me.TabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(750, 561)
        Me.Name = "Form_Demarrage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "IDEALTAKE"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.Gestion_Base_GroupBox.ResumeLayout(False)
        Me.Gestion_Base_GroupBox.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.RS_GroupBox.ResumeLayout(False)
        Me.RS_GroupBox.PerformLayout()
        CType(Me.S�parateur3_Image, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.S�parateur4_Image, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.S�parateur2_Image, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.S�parateur1_Image, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel_Image_RS.ResumeLayout(False)
        CType(Me.PictureBox_LOGO_RS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.RA_GroupBox.ResumeLayout(False)
        Me.RA_GroupBox.PerformLayout()
        Me.ContextMenuStrip2.ResumeLayout(False)
        Me.TableLayoutPanel_Image_RA.ResumeLayout(False)
        CType(Me.PictureBox_LOGO_RA, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        CType(Me.PictureBox_LOGO_Statistiques, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.GROUP_STATISTIQUE.ResumeLayout(False)
        Me.GROUP_STATISTIQUE.PerformLayout()
        CType(Me.PictureBox_Statistique_commun_verticale_droite, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_Statistique_commun_horizontale, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_Statistique_commun_verticale_gauche, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bordure_Statistique_Milieu_Verticale, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bordure_Statistique_Droite, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bordure_Statistique_Gauche, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bordure_Statistique_Basse, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bordure_Statistique_Haute, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel5.ResumeLayout(False)
        CType(Me.PICTURE_STAT, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        Me.TableLayoutPanel7.ResumeLayout(False)
        Me.Personnaliser_Conteneur_Parent_GroupBox.ResumeLayout(False)
        Me.Group_Synthese_vocale.ResumeLayout(False)
        Me.Group_Synthese_vocale.PerformLayout()
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.ResumeLayout(False)
        Me.Personnaliser_Utilisateurs_Gestion_Base_GroupBox.PerformLayout()
        Me.Personnaliser_Utilisateurs_Action_GroupBox.ResumeLayout(False)
        Me.Personnaliser_Utilisateurs_Action_GroupBox.PerformLayout()
        Me.Personnaliser_Couleurs_Recherches_GroupBox.ResumeLayout(False)
        Me.Personnaliser_Couleurs_Texte_GroupBox.ResumeLayout(False)
        Me.Personnaliser_Images__GroupBox.ResumeLayout(False)
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Aide_GroupBox.ResumeLayout(False)
        Me.Aide_GroupBox.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents RA_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Label_PARAM_H As System.Windows.Forms.Label
    Friend WithEvents ComboBox_TABLE_A As System.Windows.Forms.ComboBox
    Friend WithEvents Label_TABLE_A As System.Windows.Forms.Label
    Friend WithEvents Label_PARAM_F As System.Windows.Forms.Label
    Friend WithEvents ComboBox_TABLE_B As System.Windows.Forms.ComboBox
    Friend WithEvents Label_TABLE_B As System.Windows.Forms.Label
    Friend WithEvents ComboBox_TABLE_E As System.Windows.Forms.ComboBox
    Friend WithEvents Label_TABLE_E As System.Windows.Forms.Label
    Friend WithEvents Label_TABLE_C As System.Windows.Forms.Label
    Public WithEvents ComboBox_TABLE_C As System.Windows.Forms.ComboBox
    Friend WithEvents Button_Recherche_Avanc�e As System.Windows.Forms.Button
    Friend WithEvents WebBrowser2 As System.Windows.Forms.WebBrowser
    Friend WithEvents Label_RA_REF As System.Windows.Forms.Label
    Friend WithEvents RA_CheckBox_2 As System.Windows.Forms.CheckBox
    Friend WithEvents Label_TABLE_D As System.Windows.Forms.Label
    Friend WithEvents ComboBox_TABLE_D As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox_PARAM_H As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox_PARAM_F As System.Windows.Forms.ComboBox
    Friend WithEvents Button_Annuler_Recherche_Avanc�e As System.Windows.Forms.Button
    Friend WithEvents PictureBox_LOGO_RA As System.Windows.Forms.PictureBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Texte_Aide As System.Windows.Forms.TextBox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Gestion_Base_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents Button_Statistique_Visualiser_la_recherche As System.Windows.Forms.Button
    Friend WithEvents GROUP_STATISTIQUE As System.Windows.Forms.GroupBox
    Friend WithEvents Label_Statistique_Selection As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Statistique_Type_recherche As System.Windows.Forms.ComboBox
    Friend WithEvents Label_Statistique_Code_Document As System.Windows.Forms.Label
    Friend WithEvents TextBox_Statistique_CODE_SCHEMA As System.Windows.Forms.TextBox
    Friend WithEvents Button_Statistique_Ouvrir_Rapport_Sauvegard� As System.Windows.Forms.Button
    Friend WithEvents ComboBox_Statistique_Liste_des_Rapports_Sauvegard�s As System.Windows.Forms.ComboBox
    Friend WithEvents Label_Statistique_Rapports_Sauvegard�s As System.Windows.Forms.Label
    Friend WithEvents Button_Statistique_Suppression_Rapport_Sauvegard� As System.Windows.Forms.Button
    Friend WithEvents Button_Statistique_Effacer_la_recherche As System.Windows.Forms.Button
    Friend WithEvents PictureBox_LOGO_Statistiques As System.Windows.Forms.PictureBox
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents Button_Statistique_Imprime_un_rapport_Sauvegard� As System.Windows.Forms.Button
    Friend WithEvents Button_Statistique_S�lection_Imprimante As System.Windows.Forms.Button
    Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents PageSetupDialog1 As System.Windows.Forms.PageSetupDialog
    Friend WithEvents RA_CheckBox_1 As System.Windows.Forms.CheckBox
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents SERVEUR_DISPONIBLE As System.Windows.Forms.Label
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents Personnaliser_Couleurs_Texte_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Personnaliser_Images__GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Personnaliser_Conteneur_Parent_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents Aide_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Personnaliser_Couleurs_Recherches_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Personnaliser_Conteneur_Non_utilis�_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Personnaliser_Utilisateurs_Gestion_Base_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents Bonjour_Utilisateur As System.Windows.Forms.Label
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents RadioButton28 As System.Windows.Forms.RadioButton
    Friend WithEvents Personnaliser_Utilisateurs_Action_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton30 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton29 As System.Windows.Forms.RadioButton
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents Bouton_parametre As System.Windows.Forms.Button
    Friend WithEvents Nom_Connexion As System.Windows.Forms.Label
    Friend WithEvents Label_Nom_Connexion As System.Windows.Forms.Label
    Friend WithEvents Label_Adresse_Serveur As System.Windows.Forms.Label
    Friend WithEvents Adresse_Serveur As System.Windows.Forms.Label
    Friend WithEvents Label_Nom_de_la_base As System.Windows.Forms.Label
    Friend WithEvents Nom_de_la_base As System.Windows.Forms.Label
    Friend WithEvents Label_nom_utilisateur As System.Windows.Forms.Label
    Friend WithEvents Utilisateur As System.Windows.Forms.Label
    Friend WithEvents Diagnostique_connexion As System.Windows.Forms.Button
    Friend WithEvents Sauvegarde_Base As System.Windows.Forms.Button
    Friend WithEvents Restauration_Base As System.Windows.Forms.Button
    Friend WithEvents Restauration_Base_OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Button_Statistique_Enregistrer_Rapport As System.Windows.Forms.Button
    Friend WithEvents Label_Statistique_Nom_du_rapport_a_sauver As System.Windows.Forms.Label
    Friend WithEvents TextBox_Statistique_nom_du_rapport_�_sauver As System.Windows.Forms.TextBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Group_Synthese_vocale As System.Windows.Forms.GroupBox
    Friend WithEvents Parle As System.Windows.Forms.Button
    Friend WithEvents Parametres_synthese_vocale As System.Windows.Forms.Button
    Friend WithEvents CheckBox_Activation_synthese_vocale As System.Windows.Forms.CheckBox
    Public WithEvents Timer1EtatServeur As System.Windows.Forms.Timer
    Public WithEvents Timer2EtatServeur As System.Windows.Forms.Timer
    Friend WithEvents ZoomToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ZoomPlusToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ZoomMoinToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResetZoomToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents PictureBox_LOGO_RS As System.Windows.Forms.PictureBox
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents RS_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents RS_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents RS_NOM_ENREGISTREMENT As System.Windows.Forms.TextBox
    Friend WithEvents RS_Nom_Enregistrement_Label As System.Windows.Forms.Label
    Friend WithEvents Button_Recherche_Simplifi�e As System.Windows.Forms.Button
    Friend WithEvents Button_Annuler_Recherche_Simplifi�e As System.Windows.Forms.Button
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents T�che_de_fond As System.ComponentModel.BackgroundWorker
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel5 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents PICTURE_STAT As System.Windows.Forms.PictureBox
    Friend WithEvents TableLayoutPanel6 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem13 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackColor_ToolStripComboBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripMenuItem14 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackGroungImage_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem15 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackGroungImageLayout_ToolStripComboBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripMenuItem16 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Cursor_ToolStripComboBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripMenuItem17 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Font_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem18 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ForeColor_ToolStripComboBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripMenuItem19 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents hauteur_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem20 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Items_Allemand_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem21 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Items_Anglais_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem22 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Items_Espagnole_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem23 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Items_Francais_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem24 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Items_Italien_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem25 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents largeur_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem26 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Position_X_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem27 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Position_Y_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem28 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabIndex_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem29 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Text_Allemand_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem30 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Text_Anglais_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem31 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Text_Espagnole_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem32 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Text_Francais_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem33 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Text_Italien_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem34 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip_Allemand_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem35 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip_Anglais_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem36 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip_Espagnole_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem37 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip_Francais_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripMenuItem38 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip_Italien_ToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents TableLayoutPanel7 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents ComboBox_PARAM_G As System.Windows.Forms.ComboBox
    Friend WithEvents Label_PARAM_G As System.Windows.Forms.Label
    Friend WithEvents ComboBox_PARAM_I As System.Windows.Forms.ComboBox
    Friend WithEvents Label_PARAM_I As System.Windows.Forms.Label
    Friend WithEvents Label_PARAM_F_H As System.Windows.Forms.Label
    Friend WithEvents Label_PARAM_G_I As System.Windows.Forms.Label
    Friend WithEvents Bordure_Statistique_Milieu_Verticale As System.Windows.Forms.PictureBox
    Friend WithEvents Bordure_Statistique_Droite As System.Windows.Forms.PictureBox
    Friend WithEvents Bordure_Statistique_Gauche As System.Windows.Forms.PictureBox
    Friend WithEvents Bordure_Statistique_Basse As System.Windows.Forms.PictureBox
    Friend WithEvents Bordure_Statistique_Haute As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox_Statistique_commun_horizontale As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox_Statistique_commun_verticale_gauche As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox_Statistique_commun_verticale_droite As System.Windows.Forms.PictureBox
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents Recherche_guid�e_TreeView As System.Windows.Forms.TreeView
    Friend WithEvents WebBrowser3 As System.Windows.Forms.WebBrowser
    Friend WithEvents ImageList_TabControl1 As System.Windows.Forms.ImageList
    Friend WithEvents WebBrowser_Gestion_Base As System.Windows.Forms.WebBrowser
    Friend WithEvents Documents_Disponibles As System.Windows.Forms.ListBox
    Friend WithEvents Documents_Recherch�es As System.Windows.Forms.ListBox
    Friend WithEvents Effacer_la_liste_de_documents As System.Windows.Forms.Button
    Friend WithEvents Ajouter_un_document As System.Windows.Forms.Button
    Friend WithEvents UserControl_RA_references As UserControl1
    Friend WithEvents MenuStrip2 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem9 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem10 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem11 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem12 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem39 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RS_Mot_Clef_Label As System.Windows.Forms.Label
    Friend WithEvents RS_Inclure_Label As System.Windows.Forms.Label
    Friend WithEvents RS_Inclure_Moin_Button As System.Windows.Forms.Button
    Friend WithEvents RS_Inclure_Plus_Button As System.Windows.Forms.Button
    Friend WithEvents RS_Exclure_Label As System.Windows.Forms.Label
    Friend WithEvents RS_Exclure_Moin_Button As System.Windows.Forms.Button
    Friend WithEvents RS_Exclure_Plus_Button As System.Windows.Forms.Button
    Friend WithEvents RS_Exclure_ListBox As System.Windows.Forms.ListBox
    Friend WithEvents RS_Inclure_ListBox As System.Windows.Forms.ListBox
    Friend WithEvents RS_R�f�rences_ComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents RS_CONSTRUCTEURS_ComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents S�parateur2_Image As System.Windows.Forms.PictureBox
    Friend WithEvents S�parateur1_Image As System.Windows.Forms.PictureBox
    Friend WithEvents S�parateur3_Image As System.Windows.Forms.PictureBox
    Friend WithEvents S�parateur4_Image As System.Windows.Forms.PictureBox
    Friend WithEvents Timer_Verification_excution_SAPI5 As System.Windows.Forms.Timer
    Friend WithEvents T�che_de_fond_SAPI As System.ComponentModel.BackgroundWorker
    Friend WithEvents RS_Reference_ContextMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents Label_Sauvegarde_Base As System.Windows.Forms.Label
    Friend WithEvents RS_MOTS_CLEFS As System.Windows.Forms.TextBox
    Friend WithEvents T�che_de_fond_RS_MOTS_CLEFS As System.ComponentModel.BackgroundWorker
    Public WithEvents Timer3AutocompleteRsMotsClefs As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorker_RS As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker_RA As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker_RG As System.ComponentModel.BackgroundWorker
    Public WithEvents TimerEtatRS As System.Windows.Forms.Timer
    Public WithEvents TimerEtatRA As System.Windows.Forms.Timer
    Friend WithEvents TimerEtatRG As System.Windows.Forms.Timer
    Friend WithEvents TableLayoutPanel_Image_RS As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel_Image_RA As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents BackgroundWorker_Diagnostic As System.ComponentModel.BackgroundWorker
    Public WithEvents TimerEtatDiagnostic As System.Windows.Forms.Timer
    Friend WithEvents TimerEtatDetailsEnregistrementW1 As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerDetailsEnregistrementW1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerEtatDetailsEnregistrementW2 As System.Windows.Forms.Timer
    Friend WithEvents TimerEtatDetailsEnregistrementW3 As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerDetailsEnregistrementW2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorkerDetailsEnregistrementW3 As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerEtatRechercheGestionBase As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerRechercheGestionBase As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorkerAjoutCompteGestionBase As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerEtatAjoutCompteGestionBase As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerAuthentificationtCompteGestionBase As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerEtatAuthentificationtCompteGestionBase As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerR�cup�rationCompteGestionBase As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerEtatR�cup�rationCompteGestionBase As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerSupprimerCompteGestionBase As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerEtatSupprimerCompteGestionBase As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerSupprimeEnregistrement As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerSupprimeEnregistrement As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerAjoutEnregistrement As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerEtatAjoutEnregistrement As System.Windows.Forms.Timer
    Friend WithEvents TimerEtatAjoutTreeviewPosition As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerAjoutTreeviewPosition As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorkerAjoutLiensR�f�rences As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerEtatAjoutLiensR�f�rences As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerSupprimeLiensR�f�rences As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerEtatSupprimeLiensR�f�rences As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerTransfert As System.ComponentModel.BackgroundWorker
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents LicenceGPL As System.Windows.Forms.Button
    Friend WithEvents BackgroundWorkerChargementEnregistrement As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerChargementEnregistrement As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerMise�JourEnregistrement As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerMise�JourEnregistrement As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorkerMiniVLCPlayer As System.ComponentModel.BackgroundWorker




End Class
