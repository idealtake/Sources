'Moteur de Recherche URMET
'-------------------------
'
'
'DESCRIPTION :
'
'Moteur de recherche de documents pdf utilisant le SGBD MysQL.
'Ce logiciel a �t� developp� en VISUAL BASIC 2005.
'
'
'Copyright (C) 2006 VIEIL Thierry Ce programme est un logiciel libre ;
'vous pouvez le redistribuer et/ou le modifier au titre des clauses 
'de la Licence Publique G�n�rale GNU, telle que publi�e par la 
'Free Software Foundation ; soit la version 2 de la Licence,
'ou (� votre discr�tion) une version ult�rieure quelconque.
'Ce programme est distribu� dans l'espoir qu'il sera utile,
'mais SANS AUCUNE GARANTIE ; sans m�me une garantie implicite
'de COMMERCIABILITE ou DE CONFORMITE A UNE UTILISATION PARTICULIERE.
'
'Voir la Licence Publique G�n�rale GNU pour plus de d�tails.
'Vous devriez avoir re�u un exemplaire de la Licence Publique G�n�rale
' GNU avec ce programme ; si ce n'est pas le cas, �crivez � la  :
'
'    Free Software Foundation Inc.
'    51 Franklin Street, Fifth Floor
'    Boston, MA 02110-1301, USA.

Namespace My
    
    'This class allows you to handle specific events on the settings class:
    ' The SettingChanging event is raised before a setting's value is changed.
    ' The PropertyChanged event is raised after a setting's value is changed.
    ' The SettingsLoaded event is raised after the setting values are loaded.
    ' The SettingsSaving event is raised before the setting values are saved.
    Partial Friend NotInheritable Class MySettings
    End Class
End Namespace
