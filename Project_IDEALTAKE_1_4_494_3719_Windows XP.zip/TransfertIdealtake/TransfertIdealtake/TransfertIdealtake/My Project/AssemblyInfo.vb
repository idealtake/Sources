﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Les informations générales relatives à un assembly dépendent de 
' l'ensemble d'attributs suivant. Changez les valeurs de ces attributs pour modifier les informations
' associées à un assembly.

' Passez en revue les valeurs des attributs de l'assembly

<Assembly: AssemblyTitle("TransfertIdealtake")> 
<Assembly: AssemblyDescription("Moteur de recherche de documents utilisant le SGBD MysQL")> 
<Assembly: AssemblyCompany("VIEIL THIERRY")> 
<Assembly: AssemblyProduct("IDEALTAKE")> 
<Assembly: AssemblyCopyright("Copyright © VIEIL Thierry 2007-2013")> 
<Assembly: AssemblyTrademark("IDEALTAKE")> 

<Assembly: ComVisible(True)> 

'Le GUID suivant est pour l'ID de la typelib si ce projet est exposé à COM
<Assembly: Guid("91eaf73a-df0d-49ae-9033-f5480b0e3fb5")> 

' Les informations de version pour un assembly se composent des quatre valeurs suivantes :
'
'      Version principale
'      Version secondaire 
'      Numéro de build
'      Révision
'
' Vous pouvez spécifier toutes les valeurs ou indiquer les numéros de build et de révision par défaut 
' en utilisant '*', comme indiqué ci-dessous :
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.20.151")> 
<Assembly: AssemblyFileVersion("1.0.20.151")> 
