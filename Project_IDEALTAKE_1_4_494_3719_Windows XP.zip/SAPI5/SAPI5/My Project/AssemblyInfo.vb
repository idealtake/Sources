﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Les informations générales relatives à un assembly dépendent de 
' l'ensemble d'attributs suivant. Changez les valeurs de ces attributs pour modifier les informations
' associées à un assembly.

' Passez en revue les valeurs des attributs de l'assembly

<Assembly: AssemblyTitle("SAPI5  - AppSpeechSynthesis")> 
<Assembly: AssemblyDescription("SAPI5 Synthèse vocale Sous programme de IDEALTAKE")> 
<Assembly: AssemblyCompany("VIEIL Thierry")> 
<Assembly: AssemblyProduct("SAPI5")> 
<Assembly: AssemblyCopyright("Copyright © VIEIL Thierry 2011")> 
<Assembly: AssemblyTrademark("IDEALTAKE")> 

<Assembly: ComVisible(False)>

'Le GUID suivant est pour l'ID de la typelib si ce projet est exposé à COM
<Assembly: Guid("1af3b606-e59d-4e1f-b643-330a8e79c88c")> 

' Les informations de version pour un assembly se composent des quatre valeurs suivantes :
'
'      Version principale
'      Version secondaire 
'      Numéro de build
'      Révision
'
' Vous pouvez spécifier toutes les valeurs ou indiquer les numéros de build et de révision par défaut 
' en utilisant '*', comme indiqué ci-dessous :
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
